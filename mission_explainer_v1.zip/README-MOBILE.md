# Mission Explainer Video (v1) — মোবাইল ও পিসি রেন্ডার গাইড

## GitHub Codespaces (Android মোবাইল থেকে)
1. `mission_explainer_v1.zip` আপলোড করুন।
2. টার্মিনালে একের পর এক চালান:
   ```bash
   unzip -o mission_explainer_v1.zip
   npm install
   npm run setup
   npm run render
   ```
3. ভিডিও তৈরি হবে `out/video.mp4` ফাইলে (৪-কোর মেশিনে প্রায় ২–৪ মিনিট)।
4. ডাউনলোড করতে ফাইলটি ডান-ক্লিক করে Download দিন, অথবা `npm run download` চালিয়ে পোর্ট `8080` থেকে নিন।

## Windows PC থেকে
প্রথমবার **Node.js 18+** ইনস্টল থাকতে হবে। তারপর ফোল্ডারের ভেতরে টার্মিনাল খুলে চালান:
- `npm install`
- `npm run dev` (প্রিভিউ)
- `npm run render` (`out/video.mp4` রেন্ডার)
