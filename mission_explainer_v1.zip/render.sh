#!/usr/bin/env bash
set -e
npm install
npm run setup
npm run render
npm run thumb
echo "Rendered out/video.mp4 and out/thumbnail.png"
