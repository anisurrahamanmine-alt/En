# Asset Credits & Licenses

- **Voiceover & SRT:** `public/audio/voiceover.wav`, `original.srt`, `corrected.srt` — User provided.
- **Archival Photo:** `public/img/abraham_maslow.jpg` — User provided (`Abraham Maslow Image.jpg`).
- **Sound Effects (22 files):** `public/sfx/*.mp3` — Exclusively extracted from user-provided `Sound Effects SFX.zip`. No synthesized or external SFX added.
- **Background Music:** None (excluded respectfully for Islamic mission topic and none provided).
- **English Fonts (OFL / Open Source via @fontsource):**
  - `@fontsource/plus-jakarta-sans` (SIL OFL 1.1) — Display headlines
  - `@fontsource/inter` (SIL OFL 1.1) — UI, chips, captions
  - `@fontsource/playfair-display` (SIL OFL 1.1) — Archival caption & Hadith QuoteCard
  - `@fontsource/jetbrains-mono` (SIL OFL 1.1) — Badges, years, references
