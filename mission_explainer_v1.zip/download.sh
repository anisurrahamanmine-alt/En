#!/usr/bin/env bash
set -e
mkdir -p out
echo "Serving out/ on http://localhost:8080"
if command -v python3 >/dev/null 2>&1; then
  cd out && python3 -m http.server 8080
else
  npx http-server out -p 8080
fi
