export interface CaptionWord {
  w: string;
  s: number;
  e: number;
}

export interface CaptionChunk {
  words: CaptionWord[];
  start: number;
  end: number;
  startFrame: number;
  endFrame: number;
}

export const CAPTION_CHUNKS: CaptionChunk[] = [
  {
    "words": [
      {
        "w": "A",
        "s": 0.12,
        "e": 0.269
      },
      {
        "w": "dog",
        "s": 0.269,
        "e": 0.492
      },
      {
        "w": "eats,",
        "s": 0.492,
        "e": 0.939
      }
    ],
    "start": 0.12,
    "end": 0.939,
    "startFrame": 4,
    "endFrame": 28
  },
  {
    "words": [
      {
        "w": "sleeps,",
        "s": 0.939,
        "e": 1.535
      }
    ],
    "start": 0.939,
    "end": 1.535,
    "startFrame": 28,
    "endFrame": 46
  },
  {
    "words": [
      {
        "w": "guards",
        "s": 1.535,
        "e": 1.982
      },
      {
        "w": "its",
        "s": 1.982,
        "e": 2.206
      },
      {
        "w": "territory,",
        "s": 2.206,
        "e": 3.025
      }
    ],
    "start": 1.535,
    "end": 3.025,
    "startFrame": 46,
    "endFrame": 91
  },
  {
    "words": [
      {
        "w": "and",
        "s": 3.025,
        "e": 3.248
      },
      {
        "w": "looks",
        "s": 3.248,
        "e": 3.621
      },
      {
        "w": "for",
        "s": 3.621,
        "e": 3.844
      }
    ],
    "start": 3.025,
    "end": 3.844,
    "startFrame": 91,
    "endFrame": 115
  },
  {
    "words": [
      {
        "w": "a",
        "s": 3.844,
        "e": 3.993
      },
      {
        "w": "mate.",
        "s": 3.993,
        "e": 4.44
      }
    ],
    "start": 3.844,
    "end": 4.44,
    "startFrame": 115,
    "endFrame": 133
  },
  {
    "words": [
      {
        "w": "You",
        "s": 5.02,
        "e": 5.183
      },
      {
        "w": "do",
        "s": 5.183,
        "e": 5.292
      },
      {
        "w": "the",
        "s": 5.292,
        "e": 5.455
      }
    ],
    "start": 5.02,
    "end": 5.455,
    "startFrame": 151,
    "endFrame": 164
  },
  {
    "words": [
      {
        "w": "exact",
        "s": 5.455,
        "e": 5.727
      },
      {
        "w": "same",
        "s": 5.727,
        "e": 5.945
      },
      {
        "w": "things.",
        "s": 5.945,
        "e": 6.38
      }
    ],
    "start": 5.455,
    "end": 6.38,
    "startFrame": 164,
    "endFrame": 191
  },
  {
    "words": [
      {
        "w": "So",
        "s": 6.94,
        "e": 7.08
      },
      {
        "w": "what",
        "s": 7.08,
        "e": 7.359
      },
      {
        "w": "is",
        "s": 7.359,
        "e": 7.498
      }
    ],
    "start": 6.94,
    "end": 7.498,
    "startFrame": 208,
    "endFrame": 225
  },
  {
    "words": [
      {
        "w": "the",
        "s": 7.498,
        "e": 7.708
      },
      {
        "w": "real",
        "s": 7.708,
        "e": 7.987
      },
      {
        "w": "difference",
        "s": 7.987,
        "e": 8.685
      }
    ],
    "start": 7.498,
    "end": 8.685,
    "startFrame": 225,
    "endFrame": 261
  },
  {
    "words": [
      {
        "w": "between",
        "s": 8.685,
        "e": 9.174
      },
      {
        "w": "your",
        "s": 9.174,
        "e": 9.453
      },
      {
        "w": "life",
        "s": 9.453,
        "e": 9.732
      }
    ],
    "start": 8.685,
    "end": 9.732,
    "startFrame": 261,
    "endFrame": 292
  },
  {
    "words": [
      {
        "w": "and",
        "s": 9.732,
        "e": 9.942
      },
      {
        "w": "a",
        "s": 9.942,
        "e": 10.081
      },
      {
        "w": "dog's?",
        "s": 10.081,
        "e": 10.5
      }
    ],
    "start": 9.732,
    "end": 10.5,
    "startFrame": 292,
    "endFrame": 315
  },
  {
    "words": [
      {
        "w": "The",
        "s": 11.18,
        "e": 11.312
      },
      {
        "w": "difference",
        "s": 11.312,
        "e": 11.752
      },
      {
        "w": "is",
        "s": 11.752,
        "e": 11.84
      }
    ],
    "start": 11.18,
    "end": 11.84,
    "startFrame": 335,
    "endFrame": 355
  },
  {
    "words": [
      {
        "w": "a",
        "s": 11.84,
        "e": 11.928
      },
      {
        "w": "ladder.",
        "s": 11.928,
        "e": 12.28
      }
    ],
    "start": 11.84,
    "end": 12.28,
    "startFrame": 355,
    "endFrame": 368
  },
  {
    "words": [
      {
        "w": "Yes,",
        "s": 12.76,
        "e": 13.153
      }
    ],
    "start": 12.76,
    "end": 13.153,
    "startFrame": 383,
    "endFrame": 395
  },
  {
    "words": [
      {
        "w": "the",
        "s": 13.153,
        "e": 13.389
      },
      {
        "w": "ladder",
        "s": 13.389,
        "e": 13.86
      },
      {
        "w": "of",
        "s": 13.86,
        "e": 14.017
      }
    ],
    "start": 13.153,
    "end": 14.017,
    "startFrame": 395,
    "endFrame": 421
  },
  {
    "words": [
      {
        "w": "human",
        "s": 14.017,
        "e": 14.41
      },
      {
        "w": "needs.",
        "s": 14.41,
        "e": 14.96
      }
    ],
    "start": 14.017,
    "end": 14.96,
    "startFrame": 421,
    "endFrame": 449
  },
  {
    "words": [
      {
        "w": "In",
        "s": 15.54,
        "e": 15.696
      },
      {
        "w": "1943,",
        "s": 15.696,
        "e": 16.165
      }
    ],
    "start": 15.54,
    "end": 16.165,
    "startFrame": 466,
    "endFrame": 485
  },
  {
    "words": [
      {
        "w": "psychologist",
        "s": 16.165,
        "e": 17.102
      },
      {
        "w": "Abraham",
        "s": 17.102,
        "e": 17.648
      }
    ],
    "start": 16.165,
    "end": 17.648,
    "startFrame": 485,
    "endFrame": 529
  },
  {
    "words": [
      {
        "w": "Maslow",
        "s": 17.648,
        "e": 18.117
      },
      {
        "w": "introduced",
        "s": 18.117,
        "e": 18.897
      },
      {
        "w": "his",
        "s": 18.897,
        "e": 19.132
      }
    ],
    "start": 17.648,
    "end": 19.132,
    "startFrame": 529,
    "endFrame": 574
  },
  {
    "words": [
      {
        "w": "famous",
        "s": 19.132,
        "e": 19.6
      },
      {
        "w": "Maslow's",
        "s": 20.02,
        "e": 20.481
      }
    ],
    "start": 19.132,
    "end": 20.481,
    "startFrame": 574,
    "endFrame": 614
  },
  {
    "words": [
      {
        "w": "hierarchy",
        "s": 20.481,
        "e": 21.074
      },
      {
        "w": "of",
        "s": 21.074,
        "e": 21.205
      },
      {
        "w": "needs,",
        "s": 21.205,
        "e": 21.666
      }
    ],
    "start": 20.481,
    "end": 21.666,
    "startFrame": 614,
    "endFrame": 650
  },
  {
    "words": [
      {
        "w": "this",
        "s": 21.666,
        "e": 21.93
      },
      {
        "w": "very",
        "s": 21.93,
        "e": 22.193
      },
      {
        "w": "ladder.",
        "s": 22.193,
        "e": 22.72
      }
    ],
    "start": 21.666,
    "end": 22.72,
    "startFrame": 650,
    "endFrame": 682
  },
  {
    "words": [
      {
        "w": "He",
        "s": 23.24,
        "e": 23.378
      },
      {
        "w": "divided",
        "s": 23.378,
        "e": 23.862
      },
      {
        "w": "it",
        "s": 23.862,
        "e": 24.001
      }
    ],
    "start": 23.24,
    "end": 24.001,
    "startFrame": 697,
    "endFrame": 720
  },
  {
    "words": [
      {
        "w": "into",
        "s": 24.001,
        "e": 24.277
      },
      {
        "w": "three",
        "s": 24.277,
        "e": 24.623
      },
      {
        "w": "main",
        "s": 24.623,
        "e": 24.9
      }
    ],
    "start": 24.001,
    "end": 24.9,
    "startFrame": 720,
    "endFrame": 747
  },
  {
    "words": [
      {
        "w": "levels:",
        "s": 24.9,
        "e": 25.453
      }
    ],
    "start": 24.9,
    "end": 25.453,
    "startFrame": 747,
    "endFrame": 764
  },
  {
    "words": [
      {
        "w": "physical",
        "s": 25.453,
        "e": 26.007
      },
      {
        "w": "needs,",
        "s": 26.007,
        "e": 26.491
      }
    ],
    "start": 25.453,
    "end": 26.491,
    "startFrame": 764,
    "endFrame": 795
  },
  {
    "words": [
      {
        "w": "status",
        "s": 26.491,
        "e": 26.906
      },
      {
        "w": "needs,",
        "s": 26.906,
        "e": 27.39
      }
    ],
    "start": 26.491,
    "end": 27.39,
    "startFrame": 795,
    "endFrame": 822
  },
  {
    "words": [
      {
        "w": "and",
        "s": 27.39,
        "e": 27.598
      },
      {
        "w": "mission.",
        "s": 27.598,
        "e": 28.22
      }
    ],
    "start": 27.39,
    "end": 28.22,
    "startFrame": 822,
    "endFrame": 847
  },
  {
    "words": [
      {
        "w": "He",
        "s": 28.78,
        "e": 28.879
      },
      {
        "w": "showed",
        "s": 28.879,
        "e": 29.178
      },
      {
        "w": "that",
        "s": 29.178,
        "e": 29.377
      }
    ],
    "start": 28.78,
    "end": 29.377,
    "startFrame": 863,
    "endFrame": 881
  },
  {
    "words": [
      {
        "w": "until",
        "s": 29.377,
        "e": 29.626
      },
      {
        "w": "your",
        "s": 29.626,
        "e": 29.825
      },
      {
        "w": "lower",
        "s": 29.825,
        "e": 30.073
      }
    ],
    "start": 29.377,
    "end": 30.073,
    "startFrame": 881,
    "endFrame": 902
  },
  {
    "words": [
      {
        "w": "needs",
        "s": 30.073,
        "e": 30.322
      },
      {
        "w": "are",
        "s": 30.322,
        "e": 30.471
      },
      {
        "w": "met,",
        "s": 30.471,
        "e": 30.72
      }
    ],
    "start": 30.073,
    "end": 30.72,
    "startFrame": 902,
    "endFrame": 922
  },
  {
    "words": [
      {
        "w": "you",
        "s": 31.04,
        "e": 31.192
      },
      {
        "w": "can't",
        "s": 31.192,
        "e": 31.394
      },
      {
        "w": "even",
        "s": 31.394,
        "e": 31.596
      }
    ],
    "start": 31.04,
    "end": 31.596,
    "startFrame": 931,
    "endFrame": 948
  },
  {
    "words": [
      {
        "w": "think",
        "s": 31.596,
        "e": 31.849
      },
      {
        "w": "about",
        "s": 31.849,
        "e": 32.102
      },
      {
        "w": "the",
        "s": 32.102,
        "e": 32.253
      }
    ],
    "start": 31.596,
    "end": 32.253,
    "startFrame": 948,
    "endFrame": 968
  },
  {
    "words": [
      {
        "w": "higher",
        "s": 32.253,
        "e": 32.557
      },
      {
        "w": "ones.",
        "s": 32.557,
        "e": 32.86
      }
    ],
    "start": 32.253,
    "end": 32.86,
    "startFrame": 968,
    "endFrame": 986
  },
  {
    "words": [
      {
        "w": "For",
        "s": 33.34,
        "e": 33.523
      },
      {
        "w": "example,",
        "s": 33.523,
        "e": 34.072
      }
    ],
    "start": 33.34,
    "end": 34.072,
    "startFrame": 1000,
    "endFrame": 1022
  },
  {
    "words": [
      {
        "w": "first",
        "s": 34.072,
        "e": 34.377
      },
      {
        "w": "level,",
        "s": 34.377,
        "e": 34.805
      }
    ],
    "start": 34.072,
    "end": 34.805,
    "startFrame": 1022,
    "endFrame": 1044
  },
  {
    "words": [
      {
        "w": "physical",
        "s": 34.805,
        "e": 35.293
      },
      {
        "w": "needs.",
        "s": 35.293,
        "e": 35.72
      }
    ],
    "start": 34.805,
    "end": 35.72,
    "startFrame": 1044,
    "endFrame": 1072
  },
  {
    "words": [
      {
        "w": "Imagine",
        "s": 36.32,
        "e": 36.706
      },
      {
        "w": "you",
        "s": 36.706,
        "e": 36.872
      },
      {
        "w": "haven't",
        "s": 36.872,
        "e": 37.202
      }
    ],
    "start": 36.32,
    "end": 37.202,
    "startFrame": 1090,
    "endFrame": 1116
  },
  {
    "words": [
      {
        "w": "eaten",
        "s": 37.202,
        "e": 37.478
      },
      {
        "w": "for",
        "s": 37.478,
        "e": 37.644
      },
      {
        "w": "two",
        "s": 37.644,
        "e": 37.809
      }
    ],
    "start": 37.202,
    "end": 37.809,
    "startFrame": 1116,
    "endFrame": 1134
  },
  {
    "words": [
      {
        "w": "days.",
        "s": 37.809,
        "e": 38.14
      }
    ],
    "start": 37.809,
    "end": 38.14,
    "startFrame": 1134,
    "endFrame": 1144
  },
  {
    "words": [
      {
        "w": "Would",
        "s": 38.62,
        "e": 38.836
      },
      {
        "w": "you",
        "s": 38.836,
        "e": 38.965
      },
      {
        "w": "be",
        "s": 38.965,
        "e": 39.052
      }
    ],
    "start": 38.62,
    "end": 39.052,
    "startFrame": 1159,
    "endFrame": 1172
  },
  {
    "words": [
      {
        "w": "thinking",
        "s": 39.052,
        "e": 39.397
      },
      {
        "w": "about",
        "s": 39.397,
        "e": 39.613
      },
      {
        "w": "winning",
        "s": 39.613,
        "e": 39.915
      }
    ],
    "start": 39.052,
    "end": 39.915,
    "startFrame": 1172,
    "endFrame": 1197
  },
  {
    "words": [
      {
        "w": "a",
        "s": 39.915,
        "e": 40.002
      },
      {
        "w": "Nobel",
        "s": 40.002,
        "e": 40.218
      },
      {
        "w": "Prize?",
        "s": 40.218,
        "e": 40.52
      }
    ],
    "start": 39.915,
    "end": 40.52,
    "startFrame": 1197,
    "endFrame": 1216
  },
  {
    "words": [
      {
        "w": "Not",
        "s": 40.92,
        "e": 41.16
      },
      {
        "w": "at",
        "s": 41.16,
        "e": 41.32
      },
      {
        "w": "all.",
        "s": 41.32,
        "e": 41.72
      }
    ],
    "start": 40.92,
    "end": 41.72,
    "startFrame": 1228,
    "endFrame": 1252
  },
  {
    "words": [
      {
        "w": "Until",
        "s": 41.78,
        "e": 42.149
      },
      {
        "w": "hunger,",
        "s": 42.149,
        "e": 42.738
      }
    ],
    "start": 41.78,
    "end": 42.738,
    "startFrame": 1253,
    "endFrame": 1282
  },
  {
    "words": [
      {
        "w": "thirst,",
        "s": 42.738,
        "e": 43.328
      }
    ],
    "start": 42.738,
    "end": 43.328,
    "startFrame": 1282,
    "endFrame": 1300
  },
  {
    "words": [
      {
        "w": "and",
        "s": 43.328,
        "e": 43.549
      },
      {
        "w": "sleep",
        "s": 43.549,
        "e": 43.918
      },
      {
        "w": "are",
        "s": 43.918,
        "e": 44.139
      }
    ],
    "start": 43.328,
    "end": 44.139,
    "startFrame": 1300,
    "endFrame": 1324
  },
  {
    "words": [
      {
        "w": "satisfied,",
        "s": 44.139,
        "e": 44.95
      }
    ],
    "start": 44.139,
    "end": 44.95,
    "startFrame": 1324,
    "endFrame": 1348
  },
  {
    "words": [
      {
        "w": "every",
        "s": 44.95,
        "e": 45.318
      },
      {
        "w": "other",
        "s": 45.318,
        "e": 45.687
      },
      {
        "w": "need",
        "s": 45.687,
        "e": 45.982
      }
    ],
    "start": 44.95,
    "end": 45.982,
    "startFrame": 1348,
    "endFrame": 1379
  },
  {
    "words": [
      {
        "w": "stays",
        "s": 45.982,
        "e": 46.35
      },
      {
        "w": "silent.",
        "s": 46.35,
        "e": 46.94
      }
    ],
    "start": 45.982,
    "end": 46.94,
    "startFrame": 1379,
    "endFrame": 1408
  },
  {
    "words": [
      {
        "w": "A",
        "s": 47.44,
        "e": 47.572
      },
      {
        "w": "dog",
        "s": 47.572,
        "e": 47.769
      },
      {
        "w": "is",
        "s": 47.769,
        "e": 47.901
      }
    ],
    "start": 47.44,
    "end": 47.901,
    "startFrame": 1423,
    "endFrame": 1437
  },
  {
    "words": [
      {
        "w": "the",
        "s": 47.901,
        "e": 48.098
      },
      {
        "w": "exact",
        "s": 48.098,
        "e": 48.427
      },
      {
        "w": "same",
        "s": 48.427,
        "e": 48.691
      }
    ],
    "start": 47.901,
    "end": 48.691,
    "startFrame": 1437,
    "endFrame": 1461
  },
  {
    "words": [
      {
        "w": "way.",
        "s": 48.691,
        "e": 49.02
      }
    ],
    "start": 48.691,
    "end": 49.02,
    "startFrame": 1461,
    "endFrame": 1471
  },
  {
    "words": [
      {
        "w": "So",
        "s": 49.38,
        "e": 49.498
      },
      {
        "w": "at",
        "s": 49.498,
        "e": 49.616
      },
      {
        "w": "this",
        "s": 49.616,
        "e": 49.852
      }
    ],
    "start": 49.38,
    "end": 49.852,
    "startFrame": 1481,
    "endFrame": 1496
  },
  {
    "words": [
      {
        "w": "level,",
        "s": 49.852,
        "e": 50.264
      }
    ],
    "start": 49.852,
    "end": 50.264,
    "startFrame": 1496,
    "endFrame": 1508
  },
  {
    "words": [
      {
        "w": "there",
        "s": 50.264,
        "e": 50.559
      },
      {
        "w": "is",
        "s": 50.559,
        "e": 50.677
      },
      {
        "w": "no",
        "s": 50.677,
        "e": 50.795
      }
    ],
    "start": 50.264,
    "end": 50.795,
    "startFrame": 1508,
    "endFrame": 1524
  },
  {
    "words": [
      {
        "w": "difference",
        "s": 50.795,
        "e": 51.385
      },
      {
        "w": "between",
        "s": 51.385,
        "e": 51.798
      },
      {
        "w": "a",
        "s": 51.798,
        "e": 51.916
      }
    ],
    "start": 50.795,
    "end": 51.916,
    "startFrame": 1524,
    "endFrame": 1557
  },
  {
    "words": [
      {
        "w": "human",
        "s": 51.916,
        "e": 52.21
      },
      {
        "w": "and",
        "s": 52.21,
        "e": 52.387
      },
      {
        "w": "a",
        "s": 52.387,
        "e": 52.505
      }
    ],
    "start": 51.916,
    "end": 52.505,
    "startFrame": 1557,
    "endFrame": 1575
  },
  {
    "words": [
      {
        "w": "dog.",
        "s": 52.505,
        "e": 52.8
      }
    ],
    "start": 52.505,
    "end": 52.8,
    "startFrame": 1575,
    "endFrame": 1584
  },
  {
    "words": [
      {
        "w": "Once",
        "s": 53.38,
        "e": 53.638
      },
      {
        "w": "your",
        "s": 53.638,
        "e": 53.895
      },
      {
        "w": "hunger",
        "s": 53.895,
        "e": 54.282
      }
    ],
    "start": 53.38,
    "end": 54.282,
    "startFrame": 1601,
    "endFrame": 1628
  },
  {
    "words": [
      {
        "w": "is",
        "s": 54.282,
        "e": 54.411
      },
      {
        "w": "gone,",
        "s": 54.411,
        "e": 54.797
      }
    ],
    "start": 54.282,
    "end": 54.797,
    "startFrame": 1628,
    "endFrame": 1644
  },
  {
    "words": [
      {
        "w": "you",
        "s": 54.797,
        "e": 54.99
      },
      {
        "w": "reach",
        "s": 54.99,
        "e": 55.312
      },
      {
        "w": "the",
        "s": 55.312,
        "e": 55.505
      }
    ],
    "start": 54.797,
    "end": 55.505,
    "startFrame": 1644,
    "endFrame": 1665
  },
  {
    "words": [
      {
        "w": "second",
        "s": 55.505,
        "e": 55.892
      },
      {
        "w": "level,",
        "s": 55.892,
        "e": 56.343
      }
    ],
    "start": 55.505,
    "end": 56.343,
    "startFrame": 1665,
    "endFrame": 1690
  },
  {
    "words": [
      {
        "w": "status",
        "s": 56.343,
        "e": 56.729
      },
      {
        "w": "needs.",
        "s": 56.729,
        "e": 57.18
      }
    ],
    "start": 56.343,
    "end": 57.18,
    "startFrame": 1690,
    "endFrame": 1715
  },
  {
    "words": [
      {
        "w": "When",
        "s": 57.44,
        "e": 57.727
      },
      {
        "w": "physical",
        "s": 57.727,
        "e": 58.3
      },
      {
        "w": "needs",
        "s": 58.3,
        "e": 58.658
      }
    ],
    "start": 57.44,
    "end": 58.658,
    "startFrame": 1723,
    "endFrame": 1760
  },
  {
    "words": [
      {
        "w": "are",
        "s": 58.658,
        "e": 58.873
      },
      {
        "w": "met,",
        "s": 58.873,
        "e": 59.232
      }
    ],
    "start": 58.658,
    "end": 59.232,
    "startFrame": 1760,
    "endFrame": 1777
  },
  {
    "words": [
      {
        "w": "people",
        "s": 59.232,
        "e": 59.662
      },
      {
        "w": "want",
        "s": 59.662,
        "e": 59.948
      },
      {
        "w": "a",
        "s": 59.948,
        "e": 60.092
      }
    ],
    "start": 59.232,
    "end": 60.092,
    "startFrame": 1777,
    "endFrame": 1803
  },
  {
    "words": [
      {
        "w": "big",
        "s": 60.092,
        "e": 60.307
      },
      {
        "w": "title,",
        "s": 60.307,
        "e": 60.808
      }
    ],
    "start": 60.092,
    "end": 60.808,
    "startFrame": 1803,
    "endFrame": 1824
  },
  {
    "words": [
      {
        "w": "fame,",
        "s": 60.808,
        "e": 61.238
      }
    ],
    "start": 60.808,
    "end": 61.238,
    "startFrame": 1824,
    "endFrame": 1837
  },
  {
    "words": [
      {
        "w": "power,",
        "s": 61.238,
        "e": 61.74
      }
    ],
    "start": 61.238,
    "end": 61.74,
    "startFrame": 1837,
    "endFrame": 1852
  },
  {
    "words": [
      {
        "w": "and",
        "s": 61.74,
        "e": 61.955
      },
      {
        "w": "respect.",
        "s": 61.955,
        "e": 62.6
      }
    ],
    "start": 61.74,
    "end": 62.6,
    "startFrame": 1852,
    "endFrame": 1878
  },
  {
    "words": [
      {
        "w": "But",
        "s": 63.06,
        "e": 63.227
      },
      {
        "w": "dogs",
        "s": 63.227,
        "e": 63.449
      },
      {
        "w": "do",
        "s": 63.449,
        "e": 63.56
      }
    ],
    "start": 63.06,
    "end": 63.56,
    "startFrame": 1892,
    "endFrame": 1907
  },
  {
    "words": [
      {
        "w": "this",
        "s": 63.56,
        "e": 63.782
      },
      {
        "w": "too.",
        "s": 63.782,
        "e": 64.06
      }
    ],
    "start": 63.56,
    "end": 64.06,
    "startFrame": 1907,
    "endFrame": 1922
  },
  {
    "words": [
      {
        "w": "They",
        "s": 64.42,
        "e": 64.638
      },
      {
        "w": "mark",
        "s": 64.638,
        "e": 64.855
      },
      {
        "w": "their",
        "s": 64.855,
        "e": 65.127
      }
    ],
    "start": 64.42,
    "end": 65.127,
    "startFrame": 1933,
    "endFrame": 1954
  },
  {
    "words": [
      {
        "w": "territory",
        "s": 65.127,
        "e": 65.617
      },
      {
        "w": "with",
        "s": 65.617,
        "e": 65.835
      },
      {
        "w": "their",
        "s": 65.835,
        "e": 66.107
      }
    ],
    "start": 65.127,
    "end": 66.107,
    "startFrame": 1954,
    "endFrame": 1983
  },
  {
    "words": [
      {
        "w": "scent",
        "s": 66.107,
        "e": 66.379
      },
      {
        "w": "and",
        "s": 66.379,
        "e": 66.542
      },
      {
        "w": "fight",
        "s": 66.542,
        "e": 66.814
      }
    ],
    "start": 66.107,
    "end": 66.814,
    "startFrame": 1983,
    "endFrame": 2004
  },
  {
    "words": [
      {
        "w": "to",
        "s": 66.814,
        "e": 66.923
      },
      {
        "w": "be",
        "s": 66.923,
        "e": 67.032
      },
      {
        "w": "the",
        "s": 67.032,
        "e": 67.195
      }
    ],
    "start": 66.814,
    "end": 67.195,
    "startFrame": 2004,
    "endFrame": 2016
  },
  {
    "words": [
      {
        "w": "leader",
        "s": 67.195,
        "e": 67.521
      },
      {
        "w": "of",
        "s": 67.521,
        "e": 67.63
      },
      {
        "w": "the",
        "s": 67.63,
        "e": 67.794
      }
    ],
    "start": 67.195,
    "end": 67.794,
    "startFrame": 2016,
    "endFrame": 2034
  },
  {
    "words": [
      {
        "w": "pack.",
        "s": 67.794,
        "e": 68.12
      }
    ],
    "start": 67.794,
    "end": 68.12,
    "startFrame": 2034,
    "endFrame": 2044
  },
  {
    "words": [
      {
        "w": "That",
        "s": 68.42,
        "e": 68.669
      },
      {
        "w": "means",
        "s": 68.669,
        "e": 68.979
      },
      {
        "w": "chasing",
        "s": 68.979,
        "e": 69.414
      }
    ],
    "start": 68.42,
    "end": 69.414,
    "startFrame": 2053,
    "endFrame": 2082
  },
  {
    "words": [
      {
        "w": "fame",
        "s": 69.414,
        "e": 69.663
      },
      {
        "w": "and",
        "s": 69.663,
        "e": 69.85
      },
      {
        "w": "status",
        "s": 69.85,
        "e": 70.222
      }
    ],
    "start": 69.414,
    "end": 70.222,
    "startFrame": 2082,
    "endFrame": 2107
  },
  {
    "words": [
      {
        "w": "doesn't",
        "s": 70.222,
        "e": 70.595
      },
      {
        "w": "separate",
        "s": 70.595,
        "e": 71.093
      }
    ],
    "start": 70.222,
    "end": 71.093,
    "startFrame": 2107,
    "endFrame": 2133
  },
  {
    "words": [
      {
        "w": "humans",
        "s": 71.093,
        "e": 71.466
      },
      {
        "w": "from",
        "s": 71.466,
        "e": 71.714
      },
      {
        "w": "dogs",
        "s": 71.714,
        "e": 71.963
      }
    ],
    "start": 71.093,
    "end": 71.963,
    "startFrame": 2133,
    "endFrame": 2159
  },
  {
    "words": [
      {
        "w": "either.",
        "s": 71.963,
        "e": 72.46
      }
    ],
    "start": 71.963,
    "end": 72.46,
    "startFrame": 2159,
    "endFrame": 2174
  },
  {
    "words": [
      {
        "w": "So",
        "s": 72.98,
        "e": 73.064
      },
      {
        "w": "where",
        "s": 73.064,
        "e": 73.275
      },
      {
        "w": "is",
        "s": 73.275,
        "e": 73.359
      }
    ],
    "start": 72.98,
    "end": 73.359,
    "startFrame": 2189,
    "endFrame": 2201
  },
  {
    "words": [
      {
        "w": "the",
        "s": 73.359,
        "e": 73.486
      },
      {
        "w": "real",
        "s": 73.486,
        "e": 73.654
      },
      {
        "w": "difference?",
        "s": 73.654,
        "e": 74.16
      }
    ],
    "start": 73.359,
    "end": 74.16,
    "startFrame": 2201,
    "endFrame": 2225
  },
  {
    "words": [
      {
        "w": "The",
        "s": 74.74,
        "e": 74.911
      },
      {
        "w": "difference",
        "s": 74.911,
        "e": 75.482
      },
      {
        "w": "is",
        "s": 75.482,
        "e": 75.596
      }
    ],
    "start": 74.74,
    "end": 75.596,
    "startFrame": 2242,
    "endFrame": 2268
  },
  {
    "words": [
      {
        "w": "in",
        "s": 75.596,
        "e": 75.71
      },
      {
        "w": "the",
        "s": 75.71,
        "e": 75.881
      },
      {
        "w": "third",
        "s": 75.881,
        "e": 76.167
      }
    ],
    "start": 75.596,
    "end": 76.167,
    "startFrame": 2268,
    "endFrame": 2285
  },
  {
    "words": [
      {
        "w": "level,",
        "s": 76.167,
        "e": 76.566
      }
    ],
    "start": 76.167,
    "end": 76.566,
    "startFrame": 2285,
    "endFrame": 2297
  },
  {
    "words": [
      {
        "w": "mission.",
        "s": 76.566,
        "e": 77.08
      }
    ],
    "start": 76.566,
    "end": 77.08,
    "startFrame": 2297,
    "endFrame": 2312
  },
  {
    "words": [
      {
        "w": "What",
        "s": 77.48,
        "e": 77.675
      },
      {
        "w": "will",
        "s": 77.675,
        "e": 77.871
      },
      {
        "w": "I",
        "s": 77.871,
        "e": 77.968
      }
    ],
    "start": 77.48,
    "end": 77.968,
    "startFrame": 2324,
    "endFrame": 2339
  },
  {
    "words": [
      {
        "w": "leave",
        "s": 77.968,
        "e": 78.212
      },
      {
        "w": "behind",
        "s": 78.212,
        "e": 78.505
      },
      {
        "w": "in",
        "s": 78.505,
        "e": 78.603
      }
    ],
    "start": 77.968,
    "end": 78.603,
    "startFrame": 2339,
    "endFrame": 2358
  },
  {
    "words": [
      {
        "w": "this",
        "s": 78.603,
        "e": 78.798
      },
      {
        "w": "world?",
        "s": 78.798,
        "e": 79.14
      }
    ],
    "start": 78.603,
    "end": 79.14,
    "startFrame": 2358,
    "endFrame": 2374
  },
  {
    "words": [
      {
        "w": "This",
        "s": 79.52,
        "e": 79.72
      },
      {
        "w": "need",
        "s": 79.72,
        "e": 79.92
      },
      {
        "w": "doesn't",
        "s": 79.92,
        "e": 80.22
      }
    ],
    "start": 79.52,
    "end": 80.22,
    "startFrame": 2386,
    "endFrame": 2407
  },
  {
    "words": [
      {
        "w": "come",
        "s": 80.22,
        "e": 80.42
      },
      {
        "w": "from",
        "s": 80.42,
        "e": 80.62
      },
      {
        "w": "your",
        "s": 80.62,
        "e": 80.82
      }
    ],
    "start": 80.22,
    "end": 80.82,
    "startFrame": 2407,
    "endFrame": 2425
  },
  {
    "words": [
      {
        "w": "body.",
        "s": 80.82,
        "e": 81.12
      }
    ],
    "start": 80.82,
    "end": 81.12,
    "startFrame": 2425,
    "endFrame": 2434
  },
  {
    "words": [
      {
        "w": "Usually,",
        "s": 81.54,
        "e": 82.074
      }
    ],
    "start": 81.54,
    "end": 82.074,
    "startFrame": 2446,
    "endFrame": 2462
  },
  {
    "words": [
      {
        "w": "no",
        "s": 82.074,
        "e": 82.192
      },
      {
        "w": "one",
        "s": 82.192,
        "e": 82.37
      },
      {
        "w": "pays",
        "s": 82.37,
        "e": 82.607
      }
    ],
    "start": 82.074,
    "end": 82.607,
    "startFrame": 2462,
    "endFrame": 2478
  },
  {
    "words": [
      {
        "w": "you",
        "s": 82.607,
        "e": 82.785
      },
      {
        "w": "for",
        "s": 82.785,
        "e": 82.963
      },
      {
        "w": "it.",
        "s": 82.963,
        "e": 83.2
      }
    ],
    "start": 82.607,
    "end": 83.2,
    "startFrame": 2478,
    "endFrame": 2496
  },
  {
    "words": [
      {
        "w": "Yet",
        "s": 83.76,
        "e": 83.944
      },
      {
        "w": "it",
        "s": 83.944,
        "e": 84.067
      },
      {
        "w": "keeps",
        "s": 84.067,
        "e": 84.375
      }
    ],
    "start": 83.76,
    "end": 84.375,
    "startFrame": 2513,
    "endFrame": 2531
  },
  {
    "words": [
      {
        "w": "you",
        "s": 84.375,
        "e": 84.559
      },
      {
        "w": "awake",
        "s": 84.559,
        "e": 84.867
      },
      {
        "w": "at",
        "s": 84.867,
        "e": 84.99
      }
    ],
    "start": 84.375,
    "end": 84.99,
    "startFrame": 2531,
    "endFrame": 2550
  },
  {
    "words": [
      {
        "w": "night.",
        "s": 84.99,
        "e": 85.42
      }
    ],
    "start": 84.99,
    "end": 85.42,
    "startFrame": 2550,
    "endFrame": 2563
  },
  {
    "words": [
      {
        "w": "Now,",
        "s": 85.78,
        "e": 86.049
      }
    ],
    "start": 85.78,
    "end": 86.049,
    "startFrame": 2573,
    "endFrame": 2581
  },
  {
    "words": [
      {
        "w": "what",
        "s": 86.049,
        "e": 86.265
      },
      {
        "w": "should",
        "s": 86.265,
        "e": 86.588
      },
      {
        "w": "the",
        "s": 86.588,
        "e": 86.75
      }
    ],
    "start": 86.049,
    "end": 86.75,
    "startFrame": 2581,
    "endFrame": 2602
  },
  {
    "words": [
      {
        "w": "mission",
        "s": 86.75,
        "e": 87.127
      },
      {
        "w": "of",
        "s": 87.127,
        "e": 87.235
      },
      {
        "w": "a",
        "s": 87.235,
        "e": 87.342
      }
    ],
    "start": 86.75,
    "end": 87.342,
    "startFrame": 2602,
    "endFrame": 2620
  },
  {
    "words": [
      {
        "w": "true",
        "s": 87.342,
        "e": 87.558
      },
      {
        "w": "Muslim",
        "s": 87.558,
        "e": 87.881
      },
      {
        "w": "look",
        "s": 87.881,
        "e": 88.097
      }
    ],
    "start": 87.342,
    "end": 88.097,
    "startFrame": 2620,
    "endFrame": 2643
  },
  {
    "words": [
      {
        "w": "like?",
        "s": 88.097,
        "e": 88.42
      }
    ],
    "start": 88.097,
    "end": 88.42,
    "startFrame": 2643,
    "endFrame": 2653
  },
  {
    "words": [
      {
        "w": "It",
        "s": 88.8,
        "e": 88.916
      },
      {
        "w": "should",
        "s": 88.916,
        "e": 89.263
      },
      {
        "w": "be",
        "s": 89.263,
        "e": 89.378
      }
    ],
    "start": 88.8,
    "end": 89.378,
    "startFrame": 2664,
    "endFrame": 2681
  },
  {
    "words": [
      {
        "w": "something",
        "s": 89.378,
        "e": 89.899
      },
      {
        "w": "whose",
        "s": 89.899,
        "e": 90.188
      }
    ],
    "start": 89.378,
    "end": 90.188,
    "startFrame": 2681,
    "endFrame": 2706
  },
  {
    "words": [
      {
        "w": "rewards",
        "s": 90.188,
        "e": 90.592
      },
      {
        "w": "continue",
        "s": 90.592,
        "e": 91.055
      },
      {
        "w": "even",
        "s": 91.055,
        "e": 91.286
      }
    ],
    "start": 90.188,
    "end": 91.286,
    "startFrame": 2706,
    "endFrame": 2739
  },
  {
    "words": [
      {
        "w": "after",
        "s": 91.286,
        "e": 91.575
      },
      {
        "w": "death.",
        "s": 91.575,
        "e": 91.98
      }
    ],
    "start": 91.286,
    "end": 91.98,
    "startFrame": 2739,
    "endFrame": 2759
  },
  {
    "words": [
      {
        "w": "The",
        "s": 92.38,
        "e": 92.563
      },
      {
        "w": "Prophet",
        "s": 92.563,
        "e": 92.991
      },
      {
        "w": "Muhammad,",
        "s": 92.991,
        "e": 93.602
      }
    ],
    "start": 92.38,
    "end": 93.602,
    "startFrame": 2771,
    "endFrame": 2808
  },
  {
    "words": [
      {
        "w": "peace",
        "s": 93.602,
        "e": 93.908
      },
      {
        "w": "be",
        "s": 93.908,
        "e": 94.03
      },
      {
        "w": "upon",
        "s": 94.03,
        "e": 94.274
      }
    ],
    "start": 93.602,
    "end": 94.274,
    "startFrame": 2808,
    "endFrame": 2828
  },
  {
    "words": [
      {
        "w": "him,",
        "s": 94.274,
        "e": 94.58
      }
    ],
    "start": 94.274,
    "end": 94.58,
    "startFrame": 2828,
    "endFrame": 2837
  },
  {
    "words": [
      {
        "w": "said,",
        "s": 94.58,
        "e": 94.947
      }
    ],
    "start": 94.58,
    "end": 94.947,
    "startFrame": 2837,
    "endFrame": 2848
  },
  {
    "words": [
      {
        "w": "\"When",
        "s": 94.947,
        "e": 95.191
      },
      {
        "w": "a",
        "s": 95.191,
        "e": 95.313
      },
      {
        "w": "person",
        "s": 95.313,
        "e": 95.68
      }
    ],
    "start": 94.947,
    "end": 95.68,
    "startFrame": 2848,
    "endFrame": 2870
  },
  {
    "words": [
      {
        "w": "dies,",
        "s": 95.76,
        "e": 96.212
      }
    ],
    "start": 95.76,
    "end": 96.212,
    "startFrame": 2873,
    "endFrame": 2886
  },
  {
    "words": [
      {
        "w": "all",
        "s": 96.212,
        "e": 96.437
      },
      {
        "w": "their",
        "s": 96.437,
        "e": 96.814
      },
      {
        "w": "deeds",
        "s": 96.814,
        "e": 97.19
      }
    ],
    "start": 96.212,
    "end": 97.19,
    "startFrame": 2886,
    "endFrame": 2916
  },
  {
    "words": [
      {
        "w": "come",
        "s": 97.19,
        "e": 97.491
      },
      {
        "w": "to",
        "s": 97.491,
        "e": 97.641
      },
      {
        "w": "an",
        "s": 97.641,
        "e": 97.792
      }
    ],
    "start": 97.19,
    "end": 97.792,
    "startFrame": 2916,
    "endFrame": 2934
  },
  {
    "words": [
      {
        "w": "end",
        "s": 97.792,
        "e": 98.018
      },
      {
        "w": "except",
        "s": 98.018,
        "e": 98.469
      },
      {
        "w": "three:",
        "s": 98.469,
        "e": 98.996
      }
    ],
    "start": 97.792,
    "end": 98.996,
    "startFrame": 2934,
    "endFrame": 2970
  },
  {
    "words": [
      {
        "w": "ongoing",
        "s": 98.996,
        "e": 99.523
      },
      {
        "w": "charity,",
        "s": 99.523,
        "e": 100.2
      }
    ],
    "start": 98.996,
    "end": 100.2,
    "startFrame": 2970,
    "endFrame": 3006
  },
  {
    "words": [
      {
        "w": "beneficial",
        "s": 100.58,
        "e": 101.165
      },
      {
        "w": "knowledge,",
        "s": 101.165,
        "e": 101.808
      }
    ],
    "start": 100.58,
    "end": 101.808,
    "startFrame": 3017,
    "endFrame": 3054
  },
  {
    "words": [
      {
        "w": "and",
        "s": 101.808,
        "e": 101.984
      },
      {
        "w": "a",
        "s": 101.984,
        "e": 102.101
      },
      {
        "w": "righteous",
        "s": 102.101,
        "e": 102.627
      }
    ],
    "start": 101.808,
    "end": 102.627,
    "startFrame": 3054,
    "endFrame": 3079
  },
  {
    "words": [
      {
        "w": "child.\"",
        "s": 102.627,
        "e": 102.92
      },
      {
        "w": "This",
        "s": 103.24,
        "e": 103.45
      },
      {
        "w": "mission",
        "s": 103.45,
        "e": 103.817
      }
    ],
    "start": 102.627,
    "end": 103.817,
    "startFrame": 3079,
    "endFrame": 3115
  },
  {
    "words": [
      {
        "w": "can",
        "s": 103.817,
        "e": 103.974
      },
      {
        "w": "take",
        "s": 103.974,
        "e": 104.183
      },
      {
        "w": "many",
        "s": 104.183,
        "e": 104.393
      }
    ],
    "start": 103.817,
    "end": 104.393,
    "startFrame": 3115,
    "endFrame": 3132
  },
  {
    "words": [
      {
        "w": "forms.",
        "s": 104.393,
        "e": 104.76
      }
    ],
    "start": 104.393,
    "end": 104.76,
    "startFrame": 3132,
    "endFrame": 3143
  },
  {
    "words": [
      {
        "w": "Someone",
        "s": 105.18,
        "e": 105.532
      },
      {
        "w": "becomes",
        "s": 105.532,
        "e": 105.885
      },
      {
        "w": "an",
        "s": 105.885,
        "e": 105.986
      }
    ],
    "start": 105.18,
    "end": 105.986,
    "startFrame": 3155,
    "endFrame": 3180
  },
  {
    "words": [
      {
        "w": "imam",
        "s": 105.986,
        "e": 106.187
      },
      {
        "w": "and",
        "s": 106.187,
        "e": 106.338
      },
      {
        "w": "helps",
        "s": 106.338,
        "e": 106.59
      }
    ],
    "start": 105.986,
    "end": 106.59,
    "startFrame": 3180,
    "endFrame": 3198
  },
  {
    "words": [
      {
        "w": "people",
        "s": 106.59,
        "e": 106.892
      },
      {
        "w": "build",
        "s": 106.892,
        "e": 107.144
      },
      {
        "w": "a",
        "s": 107.144,
        "e": 107.245
      }
    ],
    "start": 106.59,
    "end": 107.245,
    "startFrame": 3198,
    "endFrame": 3217
  },
  {
    "words": [
      {
        "w": "habit",
        "s": 107.245,
        "e": 107.496
      },
      {
        "w": "of",
        "s": 107.496,
        "e": 107.597
      },
      {
        "w": "prayer.",
        "s": 107.597,
        "e": 108.0
      }
    ],
    "start": 107.245,
    "end": 108.0,
    "startFrame": 3217,
    "endFrame": 3240
  },
  {
    "words": [
      {
        "w": "Someone",
        "s": 108.44,
        "e": 108.787
      },
      {
        "w": "becomes",
        "s": 108.787,
        "e": 109.133
      },
      {
        "w": "a",
        "s": 109.133,
        "e": 109.232
      }
    ],
    "start": 108.44,
    "end": 109.232,
    "startFrame": 3253,
    "endFrame": 3277
  },
  {
    "words": [
      {
        "w": "teacher",
        "s": 109.232,
        "e": 109.579
      },
      {
        "w": "and",
        "s": 109.579,
        "e": 109.727
      },
      {
        "w": "raises",
        "s": 109.727,
        "e": 110.024
      }
    ],
    "start": 109.232,
    "end": 110.024,
    "startFrame": 3277,
    "endFrame": 3301
  },
  {
    "words": [
      {
        "w": "the",
        "s": 110.024,
        "e": 110.173
      },
      {
        "w": "next",
        "s": 110.173,
        "e": 110.371
      },
      {
        "w": "generation",
        "s": 110.371,
        "e": 110.866
      }
    ],
    "start": 110.024,
    "end": 110.866,
    "startFrame": 3301,
    "endFrame": 3326
  },
  {
    "words": [
      {
        "w": "of",
        "s": 110.866,
        "e": 110.965
      },
      {
        "w": "scholars.",
        "s": 110.965,
        "e": 111.46
      }
    ],
    "start": 110.866,
    "end": 111.46,
    "startFrame": 3326,
    "endFrame": 3344
  },
  {
    "words": [
      {
        "w": "Someone",
        "s": 111.96,
        "e": 112.38
      },
      {
        "w": "uses",
        "s": 112.38,
        "e": 112.62
      },
      {
        "w": "writing",
        "s": 112.62,
        "e": 113.04
      }
    ],
    "start": 111.96,
    "end": 113.04,
    "startFrame": 3359,
    "endFrame": 3391
  },
  {
    "words": [
      {
        "w": "or",
        "s": 113.04,
        "e": 113.16
      },
      {
        "w": "videos",
        "s": 113.16,
        "e": 113.52
      },
      {
        "w": "to",
        "s": 113.52,
        "e": 113.64
      }
    ],
    "start": 113.04,
    "end": 113.64,
    "startFrame": 3391,
    "endFrame": 3409
  },
  {
    "words": [
      {
        "w": "call",
        "s": 113.64,
        "e": 113.88
      },
      {
        "w": "people",
        "s": 113.88,
        "e": 114.24
      },
      {
        "w": "toward",
        "s": 114.24,
        "e": 114.6
      }
    ],
    "start": 113.64,
    "end": 114.6,
    "startFrame": 3409,
    "endFrame": 3438
  },
  {
    "words": [
      {
        "w": "Allah.",
        "s": 114.6,
        "e": 115.02
      }
    ],
    "start": 114.6,
    "end": 115.02,
    "startFrame": 3438,
    "endFrame": 3451
  },
  {
    "words": [
      {
        "w": "All",
        "s": 115.7,
        "e": 115.851
      },
      {
        "w": "of",
        "s": 115.851,
        "e": 115.952
      },
      {
        "w": "these",
        "s": 115.952,
        "e": 116.204
      }
    ],
    "start": 115.7,
    "end": 116.204,
    "startFrame": 3471,
    "endFrame": 3486
  },
  {
    "words": [
      {
        "w": "are",
        "s": 116.204,
        "e": 116.356
      },
      {
        "w": "missions.",
        "s": 116.356,
        "e": 116.86
      }
    ],
    "start": 116.204,
    "end": 116.86,
    "startFrame": 3486,
    "endFrame": 3506
  },
  {
    "words": [
      {
        "w": "So",
        "s": 117.3,
        "e": 117.433
      },
      {
        "w": "define",
        "s": 117.433,
        "e": 117.833
      },
      {
        "w": "your",
        "s": 117.833,
        "e": 118.1
      }
    ],
    "start": 117.3,
    "end": 118.1,
    "startFrame": 3519,
    "endFrame": 3543
  },
  {
    "words": [
      {
        "w": "own",
        "s": 118.1,
        "e": 118.3
      },
      {
        "w": "mission.",
        "s": 118.3,
        "e": 118.9
      }
    ],
    "start": 118.1,
    "end": 118.9,
    "startFrame": 3543,
    "endFrame": 3567
  },
  {
    "words": [
      {
        "w": "What",
        "s": 119.42,
        "e": 119.633
      },
      {
        "w": "do",
        "s": 119.633,
        "e": 119.74
      },
      {
        "w": "you",
        "s": 119.74,
        "e": 119.9
      }
    ],
    "start": 119.42,
    "end": 119.9,
    "startFrame": 3583,
    "endFrame": 3597
  },
  {
    "words": [
      {
        "w": "know?",
        "s": 119.9,
        "e": 120.22
      }
    ],
    "start": 119.9,
    "end": 120.22,
    "startFrame": 3597,
    "endFrame": 3607
  },
  {
    "words": [
      {
        "w": "What",
        "s": 120.36,
        "e": 120.538
      },
      {
        "w": "are",
        "s": 120.538,
        "e": 120.671
      },
      {
        "w": "you",
        "s": 120.671,
        "e": 120.804
      }
    ],
    "start": 120.36,
    "end": 120.804,
    "startFrame": 3611,
    "endFrame": 3624
  },
  {
    "words": [
      {
        "w": "good",
        "s": 120.804,
        "e": 120.982
      },
      {
        "w": "at?",
        "s": 120.982,
        "e": 121.16
      }
    ],
    "start": 120.804,
    "end": 121.16,
    "startFrame": 3624,
    "endFrame": 3635
  },
  {
    "words": [
      {
        "w": "What",
        "s": 121.56,
        "e": 121.748
      },
      {
        "w": "do",
        "s": 121.748,
        "e": 121.842
      },
      {
        "w": "you",
        "s": 121.842,
        "e": 121.983
      }
    ],
    "start": 121.56,
    "end": 121.983,
    "startFrame": 3647,
    "endFrame": 3659
  },
  {
    "words": [
      {
        "w": "love",
        "s": 121.983,
        "e": 122.171
      },
      {
        "w": "doing?",
        "s": 122.171,
        "e": 122.5
      }
    ],
    "start": 121.983,
    "end": 122.5,
    "startFrame": 3659,
    "endFrame": 3675
  },
  {
    "words": [
      {
        "w": "Bring",
        "s": 123.04,
        "e": 123.326
      },
      {
        "w": "these",
        "s": 123.326,
        "e": 123.611
      },
      {
        "w": "three",
        "s": 123.611,
        "e": 123.897
      }
    ],
    "start": 123.04,
    "end": 123.897,
    "startFrame": 3691,
    "endFrame": 3717
  },
  {
    "words": [
      {
        "w": "together",
        "s": 123.897,
        "e": 124.354
      },
      {
        "w": "and",
        "s": 124.354,
        "e": 124.526
      },
      {
        "w": "decide",
        "s": 124.526,
        "e": 124.869
      }
    ],
    "start": 123.897,
    "end": 124.869,
    "startFrame": 3717,
    "endFrame": 3746
  },
  {
    "words": [
      {
        "w": "how",
        "s": 124.869,
        "e": 125.04
      },
      {
        "w": "you",
        "s": 125.04,
        "e": 125.211
      },
      {
        "w": "will",
        "s": 125.211,
        "e": 125.44
      }
    ],
    "start": 124.869,
    "end": 125.44,
    "startFrame": 3746,
    "endFrame": 3763
  },
  {
    "words": [
      {
        "w": "call",
        "s": 125.44,
        "e": 125.669
      },
      {
        "w": "people",
        "s": 125.669,
        "e": 126.011
      },
      {
        "w": "toward",
        "s": 126.011,
        "e": 126.354
      }
    ],
    "start": 125.44,
    "end": 126.354,
    "startFrame": 3763,
    "endFrame": 3791
  },
  {
    "words": [
      {
        "w": "Allah",
        "s": 126.354,
        "e": 126.64
      },
      {
        "w": "and",
        "s": 127.0,
        "e": 127.17
      },
      {
        "w": "how",
        "s": 127.17,
        "e": 127.34
      }
    ],
    "start": 126.354,
    "end": 127.34,
    "startFrame": 3791,
    "endFrame": 3820
  },
  {
    "words": [
      {
        "w": "you",
        "s": 127.34,
        "e": 127.51
      },
      {
        "w": "will",
        "s": 127.51,
        "e": 127.737
      },
      {
        "w": "bring",
        "s": 127.737,
        "e": 128.02
      }
    ],
    "start": 127.34,
    "end": 128.02,
    "startFrame": 3820,
    "endFrame": 3841
  },
  {
    "words": [
      {
        "w": "positive",
        "s": 128.02,
        "e": 128.473
      },
      {
        "w": "change",
        "s": 128.473,
        "e": 128.813
      },
      {
        "w": "to",
        "s": 128.813,
        "e": 128.927
      }
    ],
    "start": 128.02,
    "end": 128.927,
    "startFrame": 3841,
    "endFrame": 3868
  },
  {
    "words": [
      {
        "w": "your",
        "s": 128.927,
        "e": 129.153
      },
      {
        "w": "community",
        "s": 129.153,
        "e": 129.663
      },
      {
        "w": "and",
        "s": 129.663,
        "e": 129.833
      }
    ],
    "start": 128.927,
    "end": 129.833,
    "startFrame": 3868,
    "endFrame": 3895
  },
  {
    "words": [
      {
        "w": "the",
        "s": 129.833,
        "e": 130.003
      },
      {
        "w": "world.",
        "s": 130.003,
        "e": 130.4
      }
    ],
    "start": 129.833,
    "end": 130.4,
    "startFrame": 3895,
    "endFrame": 3912
  },
  {
    "words": [
      {
        "w": "Let's",
        "s": 131.039,
        "e": 131.226
      },
      {
        "w": "go",
        "s": 131.226,
        "e": 131.319
      },
      {
        "w": "back",
        "s": 131.319,
        "e": 131.506
      }
    ],
    "start": 131.039,
    "end": 131.506,
    "startFrame": 3931,
    "endFrame": 3945
  },
  {
    "words": [
      {
        "w": "to",
        "s": 131.506,
        "e": 131.599
      },
      {
        "w": "that",
        "s": 131.599,
        "e": 131.786
      },
      {
        "w": "first",
        "s": 131.786,
        "e": 132.019
      }
    ],
    "start": 131.506,
    "end": 132.019,
    "startFrame": 3945,
    "endFrame": 3961
  },
  {
    "words": [
      {
        "w": "question",
        "s": 132.019,
        "e": 132.393
      },
      {
        "w": "about",
        "s": 132.393,
        "e": 132.626
      },
      {
        "w": "the",
        "s": 132.626,
        "e": 132.767
      }
    ],
    "start": 132.019,
    "end": 132.767,
    "startFrame": 3961,
    "endFrame": 3983
  },
  {
    "words": [
      {
        "w": "dog.",
        "s": 132.767,
        "e": 133.0
      }
    ],
    "start": 132.767,
    "end": 133.0,
    "startFrame": 3983,
    "endFrame": 3990
  },
  {
    "words": [
      {
        "w": "When",
        "s": 133.32,
        "e": 133.558
      },
      {
        "w": "it",
        "s": 133.558,
        "e": 133.677
      },
      {
        "w": "comes",
        "s": 133.677,
        "e": 133.975
      }
    ],
    "start": 133.32,
    "end": 133.975,
    "startFrame": 4000,
    "endFrame": 4019
  },
  {
    "words": [
      {
        "w": "to",
        "s": 133.975,
        "e": 134.094
      },
      {
        "w": "physical",
        "s": 134.094,
        "e": 134.57
      },
      {
        "w": "needs",
        "s": 134.57,
        "e": 134.868
      }
    ],
    "start": 133.975,
    "end": 134.868,
    "startFrame": 4019,
    "endFrame": 4046
  },
  {
    "words": [
      {
        "w": "and",
        "s": 134.868,
        "e": 135.046
      },
      {
        "w": "status,",
        "s": 135.046,
        "e": 135.522
      }
    ],
    "start": 134.868,
    "end": 135.522,
    "startFrame": 4046,
    "endFrame": 4066
  },
  {
    "words": [
      {
        "w": "there",
        "s": 135.522,
        "e": 135.82
      },
      {
        "w": "is",
        "s": 135.84,
        "e": 135.955
      },
      {
        "w": "no",
        "s": 135.955,
        "e": 136.069
      }
    ],
    "start": 135.522,
    "end": 136.069,
    "startFrame": 4066,
    "endFrame": 4082
  },
  {
    "words": [
      {
        "w": "difference",
        "s": 136.069,
        "e": 136.643
      },
      {
        "w": "between",
        "s": 136.643,
        "e": 137.045
      },
      {
        "w": "a",
        "s": 137.045,
        "e": 137.159
      }
    ],
    "start": 136.069,
    "end": 137.159,
    "startFrame": 4082,
    "endFrame": 4115
  },
  {
    "words": [
      {
        "w": "human",
        "s": 137.159,
        "e": 137.446
      },
      {
        "w": "and",
        "s": 137.446,
        "e": 137.618
      },
      {
        "w": "a",
        "s": 137.618,
        "e": 137.733
      }
    ],
    "start": 137.159,
    "end": 137.733,
    "startFrame": 4115,
    "endFrame": 4132
  },
  {
    "words": [
      {
        "w": "dog.",
        "s": 137.733,
        "e": 138.02
      }
    ],
    "start": 137.733,
    "end": 138.02,
    "startFrame": 4132,
    "endFrame": 4141
  },
  {
    "words": [
      {
        "w": "The",
        "s": 138.54,
        "e": 138.722
      },
      {
        "w": "only",
        "s": 138.722,
        "e": 138.964
      },
      {
        "w": "real",
        "s": 138.964,
        "e": 139.207
      }
    ],
    "start": 138.54,
    "end": 139.207,
    "startFrame": 4156,
    "endFrame": 4176
  },
  {
    "words": [
      {
        "w": "difference",
        "s": 139.207,
        "e": 139.813
      },
      {
        "w": "is",
        "s": 139.813,
        "e": 139.934
      },
      {
        "w": "mission.",
        "s": 139.934,
        "e": 140.48
      }
    ],
    "start": 139.207,
    "end": 140.48,
    "startFrame": 4176,
    "endFrame": 4214
  },
  {
    "words": [
      {
        "w": "Mission",
        "s": 140.98,
        "e": 141.425
      },
      {
        "w": "belongs",
        "s": 141.425,
        "e": 141.87
      },
      {
        "w": "only",
        "s": 141.87,
        "e": 142.124
      }
    ],
    "start": 140.98,
    "end": 142.124,
    "startFrame": 4229,
    "endFrame": 4264
  },
  {
    "words": [
      {
        "w": "to",
        "s": 142.124,
        "e": 142.251
      },
      {
        "w": "humans.",
        "s": 142.251,
        "e": 142.76
      }
    ],
    "start": 142.124,
    "end": 142.76,
    "startFrame": 4264,
    "endFrame": 4283
  }
];
