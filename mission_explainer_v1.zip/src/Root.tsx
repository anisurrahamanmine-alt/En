import React from "react";
import { Composition, Still } from "remotion";
import { DURATION_IN_FRAMES, FPS } from "./config";
import { LAYOUT } from "./layout";
import { MainVideo } from "./Video";
import { Thumbnail } from "./Thumbnail";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="Main"
        component={MainVideo}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={LAYOUT.w}
        height={LAYOUT.h}
      />
      <Still
        id="Thumbnail"
        component={Thumbnail}
        width={LAYOUT.w}
        height={LAYOUT.h}
      />
    </>
  );
};
