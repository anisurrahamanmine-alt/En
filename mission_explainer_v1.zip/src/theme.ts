export const THEME = {
  id: "offwhite-graph-multicolor-hybrid",
  // Base & Surfaces (Off-white graph paper)
  paper: "#FAF8F3",
  card: "#FFFFFF",
  cardWarm: "#FFFDF7",
  surfaceHi: "#F1EDE4",
  gridFine: "rgba(20, 33, 61, 0.055)",
  gridMajor: "rgba(20, 33, 61, 0.11)",
  border: "rgba(20, 33, 61, 0.13)",
  shadow: "0 18px 40px rgba(20, 33, 61, 0.14)",
  shadowSoft: "0 10px 26px rgba(20, 33, 61, 0.09)",

  // Typography
  navy: "#14213D",
  ink: "#263248",
  muted: "#64748B",
  white: "#FFFFFF",

  // All-Colors Mix Semantic Roles
  highlight: "#FCD34D",    // Warm Marker Gold (active caption, hero highlight)
  onHighlight: "#14213D",
  amber: "#D97706",        // Burnished Amber (Status, Level 2, accents/borders)
  amberSoft: "#FEF3C7",
  coral: "#E11D48",        // Rose/Coral (Hook energy, contrast)
  coralSoft: "#FFE4E6",
  bad: "#DC2626",          // Crimson (No difference, crosses, warnings)
  badSoft: "#FEE2E2",
  teal: "#0D9488",         // Emerald Teal (Mission, Level 3, Charity, truth)
  tealSoft: "#CCFBF1",
  good: "#059669",         // Forest Emerald (Verified, positive change)
  goodSoft: "#D1FAE5",
  blue: "#2563EB",         // Cobalt Blue (Physical Level 1, Psychology, Knowledge)
  blueSoft: "#DBEAFE",
  data: "#0284C7",         // Sky Blue (Data chips, clocks, beams)
  indigo: "#4F46E5",       // Indigo (Ladder structure, Writing/Videos)
  indigoSoft: "#E0E7FF",
  purple: "#7C3AED",       // Royal Violet (Passion/Love, Fame, Child)
  purpleSoft: "#EDE9FE",

  // Illustration neutral skin/hair/ground tones
  skinA: "#F1C7A5",
  skinB: "#D99B72",
  hairDark: "#1E293B",
  dogFur: "#C68B59",
  dogEar: "#8B5A2B",
  ground: "rgba(20, 33, 61, 0.18)",
} as const;

export type Theme = typeof THEME;
