import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { EASE_OUT } from "../anim";

export type TransitionType = "pushUp" | "fromRight" | "fromLeft" | "zoomIn" | "fade";

export const SceneShell: React.FC<{
  durationInFrames: number;
  enter?: TransitionType;
  exit?: TransitionType;
  children: React.ReactNode;
}> = ({ durationInFrames, enter = "pushUp", exit = "fade", children }) => {
  const f = useCurrentFrame();
  const inDur = 12;
  const outDur = 12;

  const inP = interpolate(f, [0, inDur], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: EASE_OUT,
  });
  const outP = interpolate(f, [durationInFrames - outDur, durationInFrames], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: EASE_OUT,
  });

  let tx = 0;
  let ty = 0;
  let sc = 1;

  if (enter === "pushUp") ty += (1 - inP) * 56;
  if (enter === "fromRight") tx += (1 - inP) * 90;
  if (enter === "fromLeft") tx -= (1 - inP) * 90;
  if (enter === "zoomIn") sc *= 0.92 + 0.08 * inP;

  if (exit === "pushUp") ty -= (1 - outP) * 44;
  if (exit === "fromLeft") tx -= (1 - outP) * 70;
  if (exit === "fromRight") tx += (1 - outP) * 70;
  if (exit === "zoomIn") sc *= 1 + (1 - outP) * 0.06;

  return (
    <AbsoluteFill
      style={{
        opacity: Math.min(inP, outP),
        transform: `translate3d(${tx}px, ${ty}px, 0) scale(${sc})`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
