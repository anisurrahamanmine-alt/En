import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { SCENES } from "../config";
import { THEME } from "../theme";
import { rnd } from "../anim";

export const AnimatedBg: React.FC = () => {
  const frame = useCurrentFrame();
  const activeScene =
    SCENES.find((s) => frame >= s.start && frame < s.end) ?? SCENES[SCENES.length - 1];

  // Slow continuous pan of the off-white graph grid
  const panX = (frame * 0.45) % 200;
  const panY = (frame * 0.35) % 200;
  const isArch = activeScene.bgMode === "arch";
  const isDots = activeScene.bgMode === "dots";

  const [washA, washB] = activeScene.washPair;

  return (
    <AbsoluteFill style={{ backgroundColor: THEME.paper, overflow: "hidden" }}>
      {/* Soft multi-color radial corner washes (all colors mix, refined opacity) */}
      <div
        style={{
          position: "absolute",
          inset: -100,
          background: `radial-gradient(circle at 18% 14%, ${washA} 0%, transparent 48%),
                       radial-gradient(circle at 84% 78%, ${washB} 0%, transparent 50%),
                       radial-gradient(circle at 82% 20%, rgba(252,211,77,0.09) 0%, transparent 38%)`,
        }}
      />

      {/* Off-white Graph Grid (40px fine + 200px major) — signature base across entire video */}
      <svg
        width="100%"
        height="100%"
        style={{ position: "absolute", inset: 0, opacity: isArch ? 0.65 : 1 }}
      >
        <defs>
          <pattern
            id="fineGrid"
            width={40}
            height={40}
            patternUnits="userSpaceOnUse"
            patternTransform={`translate(${panX} ${panY})`}
          >
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke={THEME.gridFine}
              strokeWidth={1.2}
            />
          </pattern>
          <pattern
            id="majorGrid"
            width={200}
            height={200}
            patternUnits="userSpaceOnUse"
            patternTransform={`translate(${panX} ${panY})`}
          >
            <rect width={200} height={200} fill="url(#fineGrid)" />
            <path
              d="M 200 0 L 0 0 0 200"
              fill="none"
              stroke={THEME.gridMajor}
              strokeWidth={1.8}
            />
          </pattern>
          <pattern
            id="dotGrid"
            width={48}
            height={48}
            patternUnits="userSpaceOnUse"
            patternTransform={`translate(${panX * 0.7} ${panY * 0.7})`}
          >
            <circle cx={24} cy={24} r={2.2} fill="rgba(20,33,61,0.11)" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#majorGrid)" />
        {isDots && <rect width="100%" height="100%" fill="url(#dotGrid)" opacity={0.7} />}
      </svg>

      {/* Subtle 8-point Islamic geometric star watermark during Scenes 7 & 8 */}
      {isArch && (
        <svg
          width={900}
          height={900}
          viewBox="0 0 400 400"
          style={{
            position: "absolute",
            left: "50%",
            top: "40%",
            transform: `translate(-50%, -50%) rotate(${frame * 0.08}deg)`,
            opacity: 0.065,
          }}
        >
          <g fill="none" stroke={THEME.teal} strokeWidth={2.5}>
            <rect x={80} y={80} width={240} height={240} />
            <rect x={80} y={80} width={240} height={240} transform="rotate(45 200 200)" />
            <circle cx={200} cy={200} r={170} strokeDasharray="8 8" stroke={THEME.amber} />
          </g>
        </svg>
      )}

      {/* Gentle deterministic floating micro-particles */}
      <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        {Array.from({ length: 14 }).map((_, i) => {
          const bx = rnd(i + 1) * 1080;
          const by = ((rnd(i + 31) * 1920 - frame * (0.25 + rnd(i + 7) * 0.35)) % 1920 + 1920) % 1920;
          const colors = [THEME.teal, THEME.amber, THEME.blue, THEME.purple, THEME.coral];
          return (
            <circle
              key={i}
              cx={bx + Math.sin(frame / 40 + i) * 10}
              cy={by}
              r={2.5 + rnd(i + 99) * 3}
              fill={colors[i % colors.length]}
              opacity={0.14}
            />
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};
