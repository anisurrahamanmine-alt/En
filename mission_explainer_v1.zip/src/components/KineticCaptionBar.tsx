import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { CAPTION_CHUNKS, CaptionChunk } from "../data/captions";
import { LAYOUT } from "../layout";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp } from "../anim";

function findActiveCaption(chunks: CaptionChunk[], t: number) {
  const hold = 0.32;
  for (let i = 0; i < chunks.length; i++) {
    const c = chunks[i];
    const next = chunks[i + 1];
    const until = next ? Math.min(next.start, c.end + hold) : c.end + hold;
    if (t >= c.start - 0.03 && t < until) {
      let activeIdx = 0;
      c.words.forEach((w, k) => {
        if (t >= w.s - 0.02) activeIdx = k;
      });
      return { chunk: c, activeIdx, idx: i };
    }
  }
  return null;
}

export const KineticCaptionBar: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;

  const state = findActiveCaption(CAPTION_CHUNKS, t);
  if (!state) return null;

  const enterP = sp(frame, state.chunk.startFrame, "snap");
  const slideY = interpolate(enterP, [0, 1], [16, 0]);
  const op = interpolate(enterP, [0, 1], [0.2, 1]);

  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top: LAYOUT.captionY,
        transform: `translateY(-50%) translateY(${slideY}px)`,
        display: "flex",
        justifyContent: "center",
        pointerEvents: "none",
        opacity: op,
        zIndex: 50,
      }}
    >
      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 10,
          padding: "14px 26px",
          borderRadius: 24,
          background: `linear-gradient(180deg, #1E3158 0%, ${THEME.navy} 100%)`,
          border: `2.5px solid rgba(252, 211, 77, 0.55)`,
          boxShadow: "0 16px 34px rgba(20, 33, 61, 0.28)",
          fontFamily: FONTS.sans,
          fontWeight: 800,
          fontSize: LAYOUT.captionFont,
          lineHeight: 1.12,
          whiteSpace: "nowrap",
        }}
      >
        {state.chunk.words.map((w, k) => {
          const isActive = k === state.activeIdx;
          const isDone = k < state.activeIdx;
          return (
            <span
              key={k}
              style={{
                padding: isActive ? "4px 14px" : "4px 6px",
                borderRadius: 12,
                backgroundColor: isActive ? THEME.highlight : "transparent",
                color: isActive
                  ? THEME.navy
                  : isDone
                    ? THEME.white
                    : "rgba(255,255,255,0.48)",
              }}
            >
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};
