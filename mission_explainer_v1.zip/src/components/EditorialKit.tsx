import React from "react";
import { Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { LAYOUT } from "../layout";
import { sp, prog, clamp01 } from "../anim";

// ── Top 3-Step Tab Bar (Physical | Status | Mission) ──
export const StepTabBar: React.FC<{ activeStep: 0 | 1 | 2 | 3 }> = ({ activeStep }) => {
  if (activeStep === 0) return null;
  const tabs = [
    { id: 1, label: "1 · Physical", color: THEME.blue },
    { id: 2, label: "2 · Status", color: THEME.amber },
    { id: 3, label: "3 · Mission", color: THEME.teal },
  ];
  return (
    <div
      style={{
        position: "absolute",
        top: LAYOUT.tabY,
        left: 0,
        right: 0,
        display: "flex",
        justifyContent: "center",
        gap: 14,
        zIndex: 40,
      }}
    >
      {tabs.map((t) => {
        const active = t.id === activeStep;
        const done = t.id < activeStep;
        return (
          <div
            key={t.id}
            style={{
              height: LAYOUT.tabH,
              padding: "0 24px",
              borderRadius: 999,
              display: "flex",
              alignItems: "center",
              gap: 8,
              backgroundColor: active ? t.color : THEME.card,
              color: active ? THEME.white : done ? THEME.navy : THEME.muted,
              border: `2.5px solid ${active ? THEME.navy : THEME.border}`,
              boxShadow: active ? "0 8px 20px rgba(20,33,61,0.18)" : THEME.shadowSoft,
              fontFamily: FONTS.sans,
              fontWeight: 800,
              fontSize: 24,
            }}
          >
            {done && (
              <span
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: "50%",
                  backgroundColor: t.color,
                  display: "inline-block",
                }}
              />
            )}
            {t.label}
          </div>
        );
      })}
    </div>
  );
};

// ── Marker-Highlighted Keyword ──
export const MarkerWord: React.FC<{
  text: string;
  at: number;
  bg?: string;
  color?: string;
  size?: number;
}> = ({ text, at, bg = THEME.highlight, color = THEME.navy, size = 84 }) => {
  const f = useCurrentFrame();
  const sweep = prog(f, at, 11);
  return (
    <span style={{ position: "relative", display: "inline-block", padding: "2px 16px" }}>
      <span
        style={{
          position: "absolute",
          inset: "4px 0",
          backgroundColor: bg,
          borderRadius: 12,
          transformOrigin: "left center",
          transform: `scaleX(${sweep})`,
          zIndex: 0,
        }}
      />
      <span
        style={{
          position: "relative",
          zIndex: 1,
          fontFamily: FONTS.display,
          fontWeight: 800,
          fontSize: size,
          color,
          letterSpacing: "-0.02em",
        }}
      >
        {text}
      </span>
    </span>
  );
};

// ── Editorial Chip / Sticker Pill ──
export const Chip: React.FC<{
  label: string;
  color: string;
  bg?: string;
  at: number;
  tilt?: number;
  icon?: React.ReactNode;
}> = ({ label, color, bg = THEME.card, at, tilt = 0, icon }) => {
  const f = useCurrentFrame();
  const p = sp(f, at, "pop");
  if (f < at) return null;
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 12,
        padding: "14px 24px",
        borderRadius: 20,
        backgroundColor: bg,
        border: `3px solid ${color}`,
        boxShadow: THEME.shadowSoft,
        transform: `translateY(${(1 - p) * 32}px) scale(${0.86 + 0.14 * p}) rotate(${tilt}deg)`,
        opacity: clamp01(p * 1.4),
        fontFamily: FONTS.sans,
        fontWeight: 800,
        fontSize: 30,
        color: THEME.navy,
      }}
    >
      {icon}
      <span>{label}</span>
    </div>
  );
};

// ── Stamp (e.g., NOT AT ALL, NO DIFFERENCE) ──
export const Stamp: React.FC<{
  text: string;
  at: number;
  color?: string;
  rot?: number;
  size?: number;
}> = ({ text, at, color = THEME.bad, rot = -5, size = 46 }) => {
  const f = useCurrentFrame();
  const p = sp(f, at, "slam");
  if (f < at) return null;
  const sc = interpolate(p, [0, 1], [1.7, 1]);
  return (
    <div
      style={{
        display: "inline-block",
        padding: "10px 28px",
        borderRadius: 14,
        border: `5px solid ${color}`,
        backgroundColor: "rgba(255,255,255,0.92)",
        color,
        fontFamily: FONTS.display,
        fontWeight: 800,
        fontSize: size,
        letterSpacing: "0.04em",
        textTransform: "uppercase",
        transform: `scale(${sc}) rotate(${rot}deg)`,
        opacity: clamp01(p * 1.6),
        boxShadow: "0 12px 28px rgba(220,38,38,0.18)",
      }}
    >
      {text}
    </div>
  );
};

// ── Animated SVG Cross Mark (✕) ──
export const CrossMark: React.FC<{ at: number; size?: number; color?: string }> = ({
  at,
  size = 120,
  color = THEME.bad,
}) => {
  const f = useCurrentFrame();
  if (f < at) return null;
  const p1 = prog(f, at, 7);
  const p2 = prog(f, at + 5, 7);
  const len = 115;
  return (
    <svg width={size} height={size} viewBox="0 0 120 120">
      <line
        x1={20}
        y1={20}
        x2={100}
        y2={100}
        stroke={color}
        strokeWidth={14}
        strokeLinecap="round"
        strokeDasharray={len}
        strokeDashoffset={len * (1 - p1)}
      />
      <line
        x1={100}
        y1={20}
        x2={20}
        y2={100}
        stroke={color}
        strokeWidth={14}
        strokeLinecap="round"
        strokeDasharray={len}
        strokeDashoffset={len * (1 - p2)}
      />
    </svg>
  );
};

// ── Animated SVG Check Mark (✓) ──
export const CheckMark: React.FC<{ at: number; size?: number; color?: string }> = ({
  at,
  size = 54,
  color = THEME.good,
}) => {
  const f = useCurrentFrame();
  if (f < at) return null;
  const p = prog(f, at, 10);
  return (
    <svg width={size} height={size} viewBox="0 0 54 54">
      <circle cx={27} cy={27} r={23} fill={color} opacity={p} />
      <path
        d="M 16 28 L 24 36 L 39 19"
        fill="none"
        stroke="#FFFFFF"
        strokeWidth={5}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={40}
        strokeDashoffset={40 * (1 - p)}
      />
    </svg>
  );
};

// ── Archival RealPhoto Frame (for Abraham Maslow 1943) ──
export const RealPhotoCard: React.FC<{
  src: string;
  caption: string;
  tag: string;
  at: number;
  width?: number;
  height?: number;
}> = ({ src, caption, tag, at, width = 520, height = 600 }) => {
  const f = useCurrentFrame();
  const p = sp(f, at, "soft");
  if (f < at) return null;
  const kb = interpolate(f - at, [0, 180], [1.03, 1.15], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <div
      style={{
        width,
        backgroundColor: THEME.cardWarm,
        padding: 18,
        paddingBottom: 24,
        borderRadius: 20,
        border: `2px solid ${THEME.border}`,
        boxShadow: THEME.shadow,
        transform: `translateY(${(1 - p) * 60}px) rotate(${interpolate(p, [0, 1], [-4, -1.5])}deg)`,
        opacity: clamp01(p * 1.3),
        position: "relative",
      }}
    >
      {/* Archival masking tape */}
      <div
        style={{
          position: "absolute",
          top: -16,
          left: "50%",
          transform: "translateX(-50%) rotate(-2deg)",
          width: 130,
          height: 32,
          backgroundColor: "rgba(252, 211, 77, 0.55)",
          border: "1px solid rgba(217,119,6,0.28)",
          borderRadius: 4,
          zIndex: 4,
        }}
      />
      <div
        style={{
          width: "100%",
          height: height - 96,
          borderRadius: 12,
          overflow: "hidden",
          position: "relative",
          backgroundColor: "#E5E7EB",
        }}
      >
        <Img
          src={staticFile(src)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center 20%",
            filter: "sepia(0.14) contrast(1.04)",
            transform: `scale(${kb})`,
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 14,
            left: 14,
            padding: "6px 14px",
            borderRadius: 8,
            backgroundColor: THEME.navy,
            color: THEME.highlight,
            fontFamily: FONTS.mono,
            fontWeight: 700,
            fontSize: 20,
          }}
        >
          {tag}
        </div>
      </div>
      <div
        style={{
          marginTop: 16,
          textAlign: "center",
          fontFamily: FONTS.serif,
          fontWeight: 700,
          fontSize: 30,
          color: THEME.navy,
        }}
      >
        {caption}
      </div>
    </div>
  );
};

// ── Horizontal Gauge Bar ──
export const GaugeBar: React.FC<{
  label: string;
  color: string;
  at: number;
  pct?: number;
}> = ({ label, color, at, pct = 1 }) => {
  const f = useCurrentFrame();
  const fillP = prog(f, at, 22) * pct;
  return (
    <div style={{ width: "100%", marginBottom: 14 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontFamily: FONTS.sans,
          fontWeight: 700,
          fontSize: 26,
          color: THEME.navy,
          marginBottom: 6,
        }}
      >
        <span>{label}</span>
        <span style={{ color }}>{Math.round(fillP * 100)}%</span>
      </div>
      <div
        style={{
          height: 22,
          borderRadius: 999,
          backgroundColor: THEME.surfaceHi,
          border: `2px solid ${THEME.border}`,
          overflow: "hidden",
        }}
      >
        <div
          style={{
            height: "100%",
            width: `${fillP * 100}%`,
            backgroundColor: color,
            borderRadius: 999,
          }}
        />
      </div>
    </div>
  );
};
