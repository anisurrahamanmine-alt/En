import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import { CompassStarArt, GlobeArt, Idle } from "../art/Illustrations";
import { MarkerWord } from "../components/EditorialKit";

const START = 2185;

export const Scene06: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const revealP = sp(F, 2248, "soft");
  const lightOpacity = prog(F, 2240, 26);

  const traits = [
    { label: "Doesn’t come from your body", tag: "SOUL", color: THEME.blue, bg: THEME.blueSoft, at: 2386 },
    { label: "Usually, no one pays you for it", tag: "UNPAID", color: THEME.amber, bg: THEME.amberSoft, at: 2446 },
    { label: "Yet it keeps you awake at night", tag: "PURPOSE", color: THEME.purple, bg: THEME.purpleSoft, at: 2513 },
  ];

  return (
    <AbsoluteFill>
      {/* Soft top editorial spotlight cone */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: "50%",
          transform: "translateX(-50%)",
          width: 900,
          height: 980,
          background:
            "radial-gradient(ellipse at 50% 0%, rgba(252,211,77,0.28) 0%, rgba(13,148,136,0.10) 45%, transparent 74%)",
          opacity: lightOpacity,
          pointerEvents: "none",
        }}
      />

      {/* Level Label */}
      <div style={{ position: "absolute", top: 232, left: 72, display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ width: 42, height: 6, borderRadius: 3, backgroundColor: THEME.teal }} />
        <span style={{ fontFamily: FONTS.mono, fontWeight: 700, fontSize: 26, color: THEME.teal }}>
          LEVEL 03 · THE REAL DIFFERENCE
        </span>
      </div>

      {/* Hero Mission Reveal */}
      {F < 2246 ? (
        <div style={{ position: "absolute", top: 520, left: 72, right: 72, textAlign: "center" }}>
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 64, color: THEME.navy }}>
            So where is the
          </div>
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 74, color: THEME.teal, marginTop: 8 }}>
            REAL DIFFERENCE?
          </div>
        </div>
      ) : (
        <>
          <div
            style={{
              position: "absolute",
              top: 300,
              left: 72,
              right: 72,
              textAlign: "center",
              transform: `translateY(${(1 - revealP) * 40}px)`,
              opacity: clamp01(revealP * 1.4),
            }}
          >
            <div style={{ display: "flex", justifyContent: "center", marginBottom: 14 }}>
              <svg width={110} height={110} viewBox="0 0 96 96">
                <Idle amp={4} speed={2.2}>
                  <CompassStarArt size={96} color={THEME.teal} />
                </Idle>
              </svg>
            </div>
            <MarkerWord text="MISSION" at={2274} bg={THEME.highlight} color={THEME.navy} size={108} />
            {F >= 2324 && (
              <div
                style={{
                  marginTop: 18,
                  fontFamily: FONTS.serif,
                  fontStyle: "italic",
                  fontWeight: 600,
                  fontSize: 38,
                  color: THEME.teal,
                  opacity: clamp01(sp(F, 2324, "soft")),
                }}
              >
                “What will I leave behind in this world?”
              </div>
            )}
          </div>

          {/* Globe emblem when "world" is spoken (f2335–2384), then 3 sleek trait cards */}
          {F >= 2330 && F < 2388 && (
            <div style={{ position: "absolute", top: 750, left: "50%", transform: "translateX(-50%)" }}>
              <GlobeArt size={220} />
            </div>
          )}

          {/* 3 Contrast Trait Cards */}
          <div
            style={{
              position: "absolute",
              top: 720,
              left: 88,
              right: 88,
              display: "flex",
              flexDirection: "column",
              gap: 22,
            }}
          >
            {traits.map((tr, i) => {
              const p = sp(F, tr.at, "pop");
              if (F < tr.at) return null;
              return (
                <div
                  key={i}
                  style={{
                    backgroundColor: THEME.card,
                    border: `3.5px solid ${tr.color}`,
                    borderRadius: 24,
                    padding: "24px 30px",
                    boxShadow: THEME.shadowSoft,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    transform: `translateY(${(1 - p) * 44}px) scale(${0.92 + 0.08 * p})`,
                    opacity: clamp01(p * 1.4),
                  }}
                >
                  <span style={{ fontFamily: FONTS.sans, fontWeight: 800, fontSize: 32, color: THEME.navy }}>
                    {tr.label}
                  </span>
                  <span
                    style={{
                      padding: "8px 18px",
                      borderRadius: 999,
                      backgroundColor: tr.bg,
                      color: tr.color,
                      fontFamily: FONTS.mono,
                      fontWeight: 700,
                      fontSize: 20,
                    }}
                  >
                    {tr.tag}
                  </span>
                </div>
              );
            })}
          </div>
        </>
      )}
    </AbsoluteFill>
  );
};
