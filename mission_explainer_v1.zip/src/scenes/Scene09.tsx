import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, clamp01 } from "../anim";
import { MosqueArt, OpenBookArt, CreatorFrameArt } from "../art/Illustrations";
import { CheckMark, MarkerWord } from "../components/EditorialKit";

const START = 3095;

export const Scene09: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const forms = [
    {
      role: "An Imam",
      desc: "Helps people build a habit of prayer",
      color: THEME.teal,
      bg: THEME.tealSoft,
      at: 3155,
      icon: <MosqueArt size={94} />,
    },
    {
      role: "A Teacher",
      desc: "Raises the next generation of scholars",
      color: THEME.blue,
      bg: THEME.blueSoft,
      at: 3253,
      icon: <OpenBookArt size={94} color={THEME.blue} />,
    },
    {
      role: "Writer / Creator",
      desc: "Uses writing or videos to call people toward Allah",
      color: THEME.indigo,
      bg: THEME.indigoSoft,
      at: 3359,
      icon: <CreatorFrameArt size={94} />,
    },
  ];

  const allChecked = F >= 3471;

  return (
    <AbsoluteFill>
      {/* Header */}
      <div style={{ position: "absolute", top: 175, left: 72, right: 72, textAlign: "center" }}>
        <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 34, color: THEME.muted }}>
          THIS MISSION CAN TAKE
        </div>
        <MarkerWord text="MANY FORMS" at={3110} bg={THEME.highlight} color={THEME.navy} size={74} />
      </div>

      {/* 3 Illustrated Role Cards */}
      <div
        style={{
          position: "absolute",
          top: 390,
          left: 76,
          right: 76,
          display: "flex",
          flexDirection: "column",
          gap: 26,
        }}
      >
        {forms.map((fm, i) => {
          const p = sp(F, fm.at, "pop");
          if (F < fm.at) return null;
          return (
            <div
              key={i}
              style={{
                backgroundColor: THEME.card,
                border: `4px solid ${fm.color}`,
                borderRadius: 28,
                padding: "24px 30px",
                boxShadow: THEME.shadow,
                display: "flex",
                alignItems: "center",
                gap: 26,
                transform: `translateX(${(1 - p) * (i % 2 === 0 ? -90 : 90)}px)`,
                opacity: clamp01(p * 1.4),
              }}
            >
              <div
                style={{
                  width: 118,
                  height: 118,
                  borderRadius: 24,
                  backgroundColor: fm.bg,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                {fm.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 38, color: fm.color }}>
                  {fm.role}
                </div>
                <div style={{ fontFamily: FONTS.sans, fontWeight: 600, fontSize: 26, color: THEME.navy, marginTop: 4, lineHeight: 1.25 }}>
                  {fm.desc}
                </div>
              </div>
              {allChecked && <CheckMark at={3471 + i * 4} size={56} color={THEME.good} />}
            </div>
          );
        })}
      </div>

      {/* Bottom Summary Banner on "All of these are missions." */}
      {allChecked && (
        <div
          style={{
            position: "absolute",
            top: 1190,
            left: 120,
            right: 120,
            padding: "18px 30px",
            borderRadius: 20,
            backgroundColor: THEME.goodSoft,
            border: `3.5px solid ${THEME.good}`,
            textAlign: "center",
            fontFamily: FONTS.display,
            fontWeight: 800,
            fontSize: 36,
            color: THEME.navy,
            transform: `scale(${0.86 + 0.14 * sp(F, 3471, "pop")})`,
          }}
        >
          ALL OF THESE ARE MISSIONS
        </div>
      )}
    </AbsoluteFill>
  );
};
