import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import {
  DogIcon,
  PersonIcon,
  Idle,
  FoodBowlIcon,
  SleepMoonIcon,
  ShieldGuardIcon,
  HeartMateIcon,
} from "../art/Illustrations";
import { Chip, MarkerWord } from "../components/EditorialKit";

const START = 0;

export const Scene01: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  // Dog slides in on frame 2; Human slides in on "You do the exact same things" (f149)
  const dogP = sp(F, 2, "pop");
  const humanP = sp(F, 148, "pop");
  const eqP = sp(F, 165, "slam");
  const qPhase = prog(F, 206, 18); // "So what is the real difference..."

  // Dog shifts left slightly when human enters
  const dogX = interpolate(humanP, [0, 1], [540, 310]);
  const humanX = interpolate(humanP, [0, 1], [1220, 770]);

  return (
    <AbsoluteFill>
      {/* Top Hero Title (shifts from opening hook to the big question at f206) */}
      <div
        style={{
          position: "absolute",
          top: 170,
          left: 72,
          right: 72,
          textAlign: "center",
        }}
      >
        {F < 204 ? (
          <div style={{ opacity: interpolate(F, [188, 204], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
            <div
              style={{
                fontFamily: FONTS.sans,
                fontWeight: 700,
                fontSize: 38,
                color: THEME.ink,
                marginBottom: 8,
                opacity: clamp01(sp(F, 4, "snap")),
              }}
            >
              A DOG’S DAILY LIFE
            </div>
            <MarkerWord text="EXACT SAME?" at={150} bg={THEME.highlight} color={THEME.navy} size={74} />
          </div>
        ) : (
          <div
            style={{
              transform: `translateY(${(1 - qPhase) * 34}px)`,
              opacity: qPhase,
            }}
          >
            <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 40, color: THEME.ink }}>
              WHAT IS THE
            </div>
            <div style={{ marginTop: 6 }}>
              <MarkerWord text="REAL DIFFERENCE" at={228} bg={THEME.highlight} color={THEME.navy} size={72} />
            </div>
            <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 36, color: THEME.muted, marginTop: 10 }}>
              between your life &amp; a dog’s?
            </div>
          </div>
        )}
      </div>

      {/* 4 Colorful Action Chips popping in on exact words (Eats f16, Sleeps f42, Guards f72, Mate f108) */}
      <div
        style={{
          position: "absolute",
          top: 430,
          left: 72,
          right: 72,
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: 18,
          opacity: interpolate(F, [198, 214], [1, 0.18], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}
      >
        <Chip label="Eats" color={THEME.coral} bg={THEME.coralSoft} at={14} tilt={-2} icon={<FoodBowlIcon size={44} />} />
        <Chip label="Sleeps" color={THEME.indigo} bg={THEME.indigoSoft} at={42} tilt={1.8} icon={<SleepMoonIcon size={44} />} />
        <Chip label="Guards Territory" color={THEME.amber} bg={THEME.amberSoft} at={70} tilt={-1.5} icon={<ShieldGuardIcon size={44} />} />
        <Chip label="Looks for a Mate" color={THEME.purple} bg={THEME.purpleSoft} at={106} tilt={1.5} icon={<HeartMateIcon size={44} />} />
      </div>

      {/* 2D Animated Diagram Stage (Ground line + Dog + Human + Equality/Question emblem) */}
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        {/* Ground Line */}
        <line
          x1={100}
          y1={1175}
          x2={980}
          y2={1175}
          stroke={THEME.ground}
          strokeWidth={5}
          strokeLinecap="round"
        />

        {/* Dog Icon */}
        <g
          transform={`translate(${dogX} ${1175 + (1 - dogP) * 90})`}
          opacity={clamp01(dogP * 1.4)}
        >
          <Idle amp={4} speed={2.6}>
            <DogIcon scale={1.38} />
          </Idle>
        </g>

        {/* Human Icon */}
        {F >= 148 && (
          <g transform={`translate(${humanX} 1175)`} opacity={clamp01(humanP * 1.4)}>
            <Idle amp={3.5} speed={2.1} phase={1.4}>
              <PersonIcon pose={F >= 210 ? "think" : "stand"} cloth={THEME.blue} scale={1.55} />
            </Idle>
          </g>
        )}

        {/* Dashed comparison connector beam between Dog and Human */}
        {F >= 164 && (
          <line
            x1={420}
            y1={1020}
            x2={660}
            y2={1020}
            stroke={F >= 212 ? THEME.coral : THEME.blue}
            strokeWidth={5}
            strokeDasharray="14 12"
            strokeDashoffset={-F * 2.5}
          />
        )}

        {/* Center Badge: "=" then morphs to giant pulsing "?" */}
        {F >= 164 && (
          <g transform={`translate(540 1020) scale(${0.6 + 0.4 * eqP + (F >= 212 ? Math.sin(F / 8) * 0.06 : 0)})`}>
            <circle
              r={54}
              fill={F >= 212 ? THEME.coral : THEME.navy}
              stroke={THEME.white}
              strokeWidth={6}
            />
            <text
              x={0}
              y={18}
              textAnchor="middle"
              fill={THEME.highlight}
              fontFamily={FONTS.display}
              fontWeight={800}
              fontSize={58}
            >
              {F >= 212 ? "?" : "="}
            </text>
          </g>
        )}
      </svg>
    </AbsoluteFill>
  );
};
