import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, clamp01 } from "../anim";
import { LadderArt, Idle } from "../art/Illustrations";
import { RealPhotoCard, MarkerWord } from "../components/EditorialKit";

const START = 325;

export const Scene02: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const ladderP = sp(F, 336, "pop");
  const photoIn = F >= 464;
  // Photo shifts slightly right when hierarchy title lands at f600
  const photoShift = sp(F, 600, "soft");
  const ladderX = interpolate(sp(F, 464, "soft"), [0, 1], [540, 270]);

  return (
    <AbsoluteFill>
      {/* Top Headline */}
      <div style={{ position: "absolute", top: 155, left: 72, right: 72, textAlign: "center" }}>
        {F < 462 ? (
          <div>
            <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 38, color: THEME.ink }}>
              THE DIFFERENCE IS A
            </div>
            <MarkerWord text="LADDER" at={348} bg={THEME.highlight} color={THEME.navy} size={96} />
            {F >= 384 && (
              <div
                style={{
                  marginTop: 12,
                  fontFamily: FONTS.sans,
                  fontWeight: 700,
                  fontSize: 34,
                  color: THEME.indigo,
                  opacity: clamp01(sp(F, 384, "snap")),
                }}
              >
                The Ladder of Human Needs
              </div>
            )}
          </div>
        ) : (
          <div>
            <div
              style={{
                display: "inline-block",
                padding: "6px 20px",
                borderRadius: 999,
                backgroundColor: THEME.blueSoft,
                border: `2px solid ${THEME.blue}`,
                fontFamily: FONTS.mono,
                fontWeight: 700,
                fontSize: 24,
                color: THEME.blue,
                marginBottom: 10,
              }}
            >
              PSYCHOLOGY · 1943
            </div>
            <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 56, color: THEME.navy, lineHeight: 1.12 }}>
              Maslow’s{" "}
              <MarkerWord text="Hierarchy" at={602} bg={THEME.highlight} color={THEME.navy} size={56} />
            </div>
          </div>
        )}
      </div>

      {/* 2D Animated Ladder SVG */}
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        <line x1={90} y1={1220} x2={990} y2={1220} stroke={THEME.ground} strokeWidth={5} strokeLinecap="round" />
        <g
          transform={`translate(${ladderX} ${1220 + (1 - ladderP) * 240})`}
          opacity={clamp01(ladderP * 1.4)}
        >
          <Idle amp={3} speed={1.8}>
            <LadderArt height={660} width={220} activeLevel={0} />
          </Idle>
        </g>
      </svg>

      {/* Archival Collage Photo of Abraham Maslow (1943) */}
      {photoIn && (
        <div
          style={{
            position: "absolute",
            top: 430,
            right: interpolate(photoShift, [0, 1], [86, 68]),
            transform: `scale(${interpolate(photoShift, [0, 1], [1, 0.94])})`,
          }}
        >
          <RealPhotoCard
            src="img/abraham_maslow.jpg"
            tag="ARCHIVAL · 1943"
            caption="Abraham Maslow (Psychologist)"
            at={464}
            width={510}
            height={610}
          />
        </div>
      )}
    </AbsoluteFill>
  );
};
