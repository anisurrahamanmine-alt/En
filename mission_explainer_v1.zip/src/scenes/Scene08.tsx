import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, clamp01 } from "../anim";
import { TreeCharityArt, OpenBookArt, RighteousChildArt } from "../art/Illustrations";

const START = 2768;

export const Scene08: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const cardP = sp(F, 2772, "soft");

  const pillars = [
    {
      title: "Ongoing Charity",
      sub: "Sadaqah Jariyah",
      color: THEME.teal,
      bg: THEME.tealSoft,
      at: 2982,
      art: <TreeCharityArt size={96} />,
    },
    {
      title: "Beneficial Knowledge",
      sub: "Shared & Taught",
      color: THEME.blue,
      bg: THEME.blueSoft,
      at: 3016,
      art: <OpenBookArt size={96} color={THEME.blue} />,
    },
    {
      title: "Righteous Child",
      sub: "Who Prays for Them",
      color: THEME.purple,
      bg: THEME.purpleSoft,
      at: 3050,
      art: <RighteousChildArt size={96} />,
    },
  ];

  return (
    <AbsoluteFill>
      {/* Dignified Editorial Hadith QuoteCard */}
      <div
        style={{
          position: "absolute",
          top: 165,
          left: 72,
          right: 72,
          backgroundColor: THEME.cardWarm,
          border: `3.5px solid ${THEME.amber}`,
          borderRadius: 30,
          padding: "36px 40px 30px",
          boxShadow: THEME.shadow,
          transform: `translateY(${(1 - cardP) * 40}px) scale(${0.95 + 0.05 * cardP})`,
          opacity: clamp01(cardP * 1.4),
        }}
      >
        {/* Header Badge */}
        <div
          style={{
            display: "inline-block",
            padding: "8px 20px",
            borderRadius: 999,
            backgroundColor: THEME.amberSoft,
            border: `2px solid ${THEME.amber}`,
            fontFamily: FONTS.mono,
            fontWeight: 700,
            fontSize: 22,
            color: THEME.navy,
            marginBottom: 18,
          }}
        >
          PROPHET MUHAMMAD (ﷺ) SAID
        </div>

        {/* Exact Hadith Quote */}
        <div
          style={{
            fontFamily: FONTS.serif,
            fontStyle: "italic",
            fontWeight: 600,
            fontSize: 34,
            lineHeight: 1.42,
            color: THEME.navy,
          }}
        >
          “When a person dies, all their deeds come to an end except for{" "}
          <span
            style={{
              backgroundColor: THEME.highlight,
              padding: "2px 10px",
              borderRadius: 8,
              fontStyle: "normal",
              fontWeight: 700,
            }}
          >
            three
          </span>
          : ongoing charity (Sadaqah Jariyah), beneficial knowledge, or a righteous child who prays for them.”
        </div>

        {/* Source Footer Bar */}
        <div
          style={{
            marginTop: 22,
            paddingTop: 16,
            borderTop: `2px solid ${THEME.border}`,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <span style={{ fontFamily: FONTS.mono, fontWeight: 700, fontSize: 22, color: THEME.teal }}>
            Hadith — Sahih Muslim : 1631
          </span>
          <span style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 20, color: THEME.muted }}>
            AUTHENTIC
          </span>
        </div>
      </div>

      {/* 3 Illustrated Legacy Pillars rising on exact spoken cues */}
      <div
        style={{
          position: "absolute",
          top: 790,
          left: 68,
          right: 68,
          display: "flex",
          justifyContent: "space-between",
          gap: 18,
        }}
      >
        {pillars.map((pl, idx) => {
          const p = sp(F, pl.at, "pop");
          if (F < pl.at) return <div key={idx} style={{ flex: 1 }} />;
          return (
            <div
              key={idx}
              style={{
                flex: 1,
                backgroundColor: THEME.card,
                border: `3.5px solid ${pl.color}`,
                borderRadius: 26,
                padding: "22px 16px",
                boxShadow: THEME.shadowSoft,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                textAlign: "center",
                transform: `translateY(${(1 - p) * 60}px) scale(${0.88 + 0.12 * p})`,
                opacity: clamp01(p * 1.4),
              }}
            >
              <div
                style={{
                  width: 112,
                  height: 112,
                  borderRadius: 24,
                  backgroundColor: pl.bg,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 14,
                }}
              >
                {pl.art}
              </div>
              <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 26, color: THEME.navy, lineHeight: 1.15 }}>
                {pl.title}
              </div>
              <div style={{ fontFamily: FONTS.sans, fontWeight: 600, fontSize: 20, color: pl.color, marginTop: 6 }}>
                {pl.sub}
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
