import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import { DogIcon, PersonIcon, LadderArt, CompassStarArt, Idle } from "../art/Illustrations";
import { MarkerWord } from "../components/EditorialKit";

const START = 3925;

export const Scene11: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const finalMode = F >= 4152; // "The only real difference is mission."
  const glowP = prog(F, 4152, 28);
  const heroP = sp(F, 4158, "soft");

  return (
    <AbsoluteFill>
      {/* Full-bleed warm editorial sunrise glow on final resolution (properly sized beyond 1080x1920) */}
      <div
        style={{
          position: "absolute",
          left: -140,
          top: -140,
          width: 1360,
          height: 2200,
          background:
            "radial-gradient(circle at 50% 34%, rgba(252,211,77,0.34) 0%, rgba(13,148,136,0.16) 44%, rgba(250,248,243,0) 76%)",
          opacity: glowP,
          pointerEvents: "none",
        }}
      />

      {/* Phase A (3925–4152): Callback to Levels 1 & 2 (Human = Dog) */}
      {!finalMode && (
        <>
          <div style={{ position: "absolute", top: 185, left: 72, right: 72, textAlign: "center" }}>
            <div style={{ fontFamily: FONTS.mono, fontWeight: 700, fontSize: 24, color: THEME.muted }}>
              BACK TO THE FIRST QUESTION
            </div>
            <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 52, color: THEME.navy, marginTop: 10 }}>
              Physical &amp; Status Needs
            </div>
            {F >= 4065 && (
              <div
                style={{
                  display: "inline-block",
                  marginTop: 16,
                  padding: "8px 26px",
                  borderRadius: 14,
                  backgroundColor: THEME.badSoft,
                  border: `3px solid ${THEME.bad}`,
                  fontFamily: FONTS.display,
                  fontWeight: 800,
                  fontSize: 34,
                  color: THEME.bad,
                }}
              >
                NO DIFFERENCE
              </div>
            )}
          </div>

          <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
            <line x1={90} y1={1200} x2={990} y2={1200} stroke={THEME.ground} strokeWidth={5} strokeLinecap="round" />
            <g transform="translate(540 1200)" opacity={0.45}>
              <LadderArt height={560} width={200} activeLevel={0} />
            </g>
            <g transform="translate(300 1200)">
              <Idle amp={3} speed={2.2}>
                <DogIcon scale={1.25} />
              </Idle>
            </g>
            <g transform="translate(780 1200)">
              <Idle amp={3} speed={2.2} phase={1}>
                <PersonIcon pose="stand" cloth={THEME.blue} scale={1.45} />
              </Idle>
            </g>
          </svg>
        </>
      )}

      {/* Phase B (4152–4320): Poster-Worthy Climax & Closing Hold */}
      {finalMode && (
        <>
          <div
            style={{
              position: "absolute",
              top: 230,
              left: 72,
              right: 72,
              textAlign: "center",
              transform: `translateY(${(1 - heroP) * 44}px)`,
              opacity: clamp01(heroP * 1.4),
            }}
          >
            <div style={{ display: "flex", justifyContent: "center", marginBottom: 18 }}>
              <svg width={120} height={120} viewBox="0 0 96 96">
                <Idle amp={4} speed={2}>
                  <CompassStarArt size={96} color={THEME.teal} />
                </Idle>
              </svg>
            </div>
            <div style={{ fontFamily: FONTS.sans, fontWeight: 800, fontSize: 34, color: THEME.teal, letterSpacing: "0.08em" }}>
              THE ONLY REAL DIFFERENCE
            </div>
            <div style={{ marginTop: 12 }}>
              <MarkerWord text="MISSION" at={4168} bg={THEME.highlight} color={THEME.navy} size={112} />
            </div>
            {F >= 4228 && (
              <div
                style={{
                  marginTop: 22,
                  fontFamily: FONTS.display,
                  fontWeight: 800,
                  fontSize: 48,
                  color: THEME.navy,
                  opacity: clamp01(sp(F, 4228, "soft")),
                }}
              >
                BELONGS ONLY TO HUMANS.
              </div>
            )}
          </div>

          {/* Human standing tall at the summit of the Ladder */}
          <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
            <line x1={120} y1={1265} x2={960} y2={1265} stroke={THEME.teal} strokeWidth={5} strokeLinecap="round" opacity={0.45} />
            <g transform="translate(540 1265)">
              <rect x={-160} y={-24} width={320} height={24} rx={12} fill={THEME.teal} stroke={THEME.navy} strokeWidth={4} />
              <g transform="translate(0 -24)">
                <Idle amp={4} speed={2}>
                  <PersonIcon pose="celebrate" cloth={THEME.teal} scale={1.68} />
                </Idle>
              </g>
            </g>
          </svg>
        </>
      )}
    </AbsoluteFill>
  );
};
