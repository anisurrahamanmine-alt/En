import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import { PersonIcon, DogIcon, NobelMedalArt, Idle } from "../art/Illustrations";
import { CrossMark, Stamp, GaugeBar } from "../components/EditorialKit";

const START = 995;

export const Scene04: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const personP = sp(F, 1005, "pop");
  const timerP = sp(F, 1090, "pop");
  const nobelP = sp(F, 1160, "pop");
  const showGauges = F >= 1255 && F < 1420;
  const showDogCompare = F >= 1420;
  const dogP = sp(F, 1424, "pop");

  // Clock hand rotation for "2 days"
  const clockAngle = interpolate(F, [1090, 1150], [0, 720], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill>
      {/* Level Label */}
      <div style={{ position: "absolute", top: 232, left: 72, display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ width: 42, height: 6, borderRadius: 3, backgroundColor: THEME.blue }} />
        <span style={{ fontFamily: FONTS.mono, fontWeight: 700, fontSize: 26, color: THEME.blue }}>
          LEVEL 01 · PHYSICAL NEEDS
        </span>
      </div>

      {/* Phase A (1090–1255): 2 Days Hungry vs Nobel Prize */}
      {F >= 1090 && F < 1260 && (
        <>
          {/* 2 Days Timer Chip */}
          <div
            style={{
              position: "absolute",
              top: 320,
              left: 82,
              backgroundColor: THEME.card,
              border: `3.5px solid ${THEME.bad}`,
              borderRadius: 24,
              padding: "18px 28px",
              boxShadow: THEME.shadowSoft,
              display: "flex",
              alignItems: "center",
              gap: 20,
              transform: `scale(${0.85 + 0.15 * timerP})`,
              opacity: clamp01(timerP * 1.4),
            }}
          >
            <svg width={76} height={76} viewBox="0 0 76 76">
              <circle cx={38} cy={38} r={32} fill={THEME.badSoft} stroke={THEME.bad} strokeWidth={5} />
              <line
                x1={38}
                y1={38}
                x2={38 + Math.sin((clockAngle * Math.PI) / 180) * 20}
                y2={38 - Math.cos((clockAngle * Math.PI) / 180) * 20}
                stroke={THEME.navy}
                strokeWidth={5}
                strokeLinecap="round"
              />
              <circle cx={38} cy={38} r={4} fill={THEME.navy} />
            </svg>
            <div>
              <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 44, color: THEME.bad, lineHeight: 1 }}>
                2 DAYS
              </div>
              <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 22, color: THEME.muted }}>
                WITHOUT FOOD
              </div>
            </div>
          </div>

          {/* Nobel Prize Thought Bubble + Cross + NOT AT ALL Stamp */}
          {F >= 1158 && (
            <div
              style={{
                position: "absolute",
                top: 470,
                right: 84,
                width: 390,
                backgroundColor: THEME.card,
                border: `3.5px solid ${THEME.amber}`,
                borderRadius: 34,
                padding: "26px 24px",
                boxShadow: THEME.shadow,
                textAlign: "center",
                transform: `scale(${0.8 + 0.2 * nobelP})`,
                opacity: clamp01(nobelP * 1.4),
              }}
            >
              <div style={{ position: "relative", display: "inline-block" }}>
                <NobelMedalArt size={146} />
                {F >= 1222 && (
                  <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <CrossMark at={1222} size={138} color={THEME.bad} />
                  </div>
                )}
              </div>
              <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 32, color: THEME.navy, marginTop: 8 }}>
                Nobel Prize?
              </div>
              {F >= 1228 && (
                <div style={{ marginTop: 14 }}>
                  <Stamp text="NOT AT ALL" at={1228} color={THEME.bad} rot={-4} size={34} />
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Phase B (1255–1420): Hunger, Thirst & Sleep Gauges */}
      {showGauges && (
        <div
          style={{
            position: "absolute",
            top: 340,
            left: 92,
            right: 92,
            backgroundColor: THEME.card,
            border: `3.5px solid ${THEME.blue}`,
            borderRadius: 30,
            padding: "32px 36px",
            boxShadow: THEME.shadow,
            opacity: prog(F, 1255, 10),
          }}
        >
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 36, color: THEME.navy, marginBottom: 22 }}>
            Survival Essentials First
          </div>
          <GaugeBar label="Hunger (Food)" color={THEME.coral} at={1264} pct={1} />
          <GaugeBar label="Thirst (Water)" color={THEME.blue} at={1298} pct={1} />
          <GaugeBar label="Sleep (Rest)" color={THEME.indigo} at={1332} pct={1} />
        </div>
      )}

      {/* Phase C (1420–1595): Human = Dog at Physical Level */}
      {showDogCompare && (
        <div style={{ position: "absolute", top: 360, left: 72, right: 72, textAlign: "center" }}>
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 52, color: THEME.navy }}>
            Human &amp; Dog
          </div>
          <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 30, color: THEME.muted, marginTop: 6 }}>
            Both driven by survival instincts
          </div>
          {F >= 1515 && (
            <div style={{ marginTop: 28 }}>
              <Stamp text="NO DIFFERENCE" at={1515} color={THEME.bad} rot={-3} size={44} />
            </div>
          )}
        </div>
      )}

      {/* 2D Animated Stage (Ground + Human + Dog) */}
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        <line x1={90} y1={1225} x2={990} y2={1225} stroke={THEME.ground} strokeWidth={5} strokeLinecap="round" />

        {/* Platform bar representing Level 1 */}
        <rect x={140} y={1225} width={800} height={24} rx={12} fill={THEME.blue} stroke={THEME.navy} strokeWidth={4} />

        {/* Human Icon */}
        <g
          transform={`translate(${showDogCompare ? 340 : 280} ${1225 + (1 - personP) * 90})`}
          opacity={clamp01(personP * 1.4)}
        >
          <Idle amp={3.5} speed={2.2}>
            <PersonIcon pose={F < 1255 ? "think" : "stand"} cloth={THEME.blue} scale={1.55} />
          </Idle>
        </g>

        {/* Dog Icon joins on C16 */}
        {showDogCompare && (
          <g transform={`translate(${interpolate(dogP, [0, 1], [1160, 740])} 1225)`} opacity={clamp01(dogP * 1.4)}>
            <Idle amp={4} speed={2.6} phase={1}>
              <DogIcon scale={1.35} flip />
            </Idle>
          </g>
        )}
      </svg>
    </AbsoluteFill>
  );
};
