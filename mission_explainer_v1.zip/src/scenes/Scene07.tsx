import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import { MosqueArt, Idle } from "../art/Illustrations";
import { MarkerWord } from "../components/EditorialKit";

const START = 2570;

export const Scene07: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const archP = sp(F, 2578, "soft");
  const lineP = prog(F, 2664, 48);

  return (
    <AbsoluteFill>
      {/* Top Question */}
      <div
        style={{
          position: "absolute",
          top: 195,
          left: 72,
          right: 72,
          textAlign: "center",
          opacity: clamp01(archP * 1.4),
          transform: `translateY(${(1 - archP) * 32}px)`,
        }}
      >
        <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 36, color: THEME.ink }}>
          THE MISSION OF A
        </div>
        <div style={{ marginTop: 8 }}>
          <MarkerWord text="TRUE MUSLIM" at={2600} bg={THEME.highlight} color={THEME.navy} size={74} />
        </div>
      </div>

      {/* Serene Architectural Arch Frame (no sacred figures) */}
      <div
        style={{
          position: "absolute",
          top: 430,
          left: "50%",
          transform: `translateX(-50%) scale(${0.92 + 0.08 * archP})`,
          width: 440,
          height: 360,
          borderRadius: "220px 220px 28px 28px",
          backgroundColor: THEME.cardWarm,
          border: `4px solid ${THEME.amber}`,
          boxShadow: THEME.shadow,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          opacity: clamp01(archP * 1.4),
        }}
      >
        <svg width={140} height={140} viewBox="0 0 120 120">
          <Idle amp={3} speed={1.8}>
            <MosqueArt size={120} />
          </Idle>
        </svg>
        <div style={{ fontFamily: FONTS.serif, fontWeight: 700, fontSize: 30, color: THEME.teal, marginTop: 10 }}>
          Eternal Legacy
        </div>
      </div>

      {/* Timeline Diagram: THIS LIFE -> BEYOND DEATH (Continuous Rewards) */}
      {F >= 2660 && (
        <div
          style={{
            position: "absolute",
            top: 860,
            left: 76,
            right: 76,
            backgroundColor: THEME.card,
            border: `3.5px solid ${THEME.teal}`,
            borderRadius: 28,
            padding: "30px 34px",
            boxShadow: THEME.shadow,
            opacity: prog(F, 2660, 14),
          }}
        >
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 32, color: THEME.navy, textAlign: "center", marginBottom: 20 }}>
            Rewards That Continue After Death
          </div>
          <svg width={860} height={150} viewBox="0 0 860 150">
            {/* Base timeline */}
            <line x1={30} y1={75} x2={830} y2={75} stroke={THEME.surfaceHi} strokeWidth={12} strokeLinecap="round" />
            {/* Animated progress beam */}
            <line
              x1={30}
              y1={75}
              x2={30 + 780 * lineP}
              y2={75}
              stroke={THEME.teal}
              strokeWidth={12}
              strokeLinecap="round"
            />
            {/* Vertical Death Milestone */}
            <line x1={390} y1={24} x2={390} y2={126} stroke={THEME.amber} strokeWidth={4} strokeDasharray="8 6" />
            <circle cx={390} cy={75} r={14} fill={THEME.amber} stroke={THEME.navy} strokeWidth={4} />
            {/* Labels */}
            <text x={180} y={132} textAnchor="middle" fill={THEME.muted} fontFamily={FONTS.mono} fontWeight={700} fontSize={22}>
              THIS LIFE
            </text>
            <text x={620} y={132} textAnchor="middle" fill={THEME.teal} fontFamily={FONTS.mono} fontWeight={700} fontSize={22}>
              CONTINUES FOREVER →
            </text>
            {/* Glowing reward particles beyond the milestone */}
            {lineP > 0.55 &&
              [470, 560, 650, 740].map((cx, idx) => {
                const lift = ((F * 1.4 + idx * 17) % 34);
                return (
                  <circle
                    key={idx}
                    cx={cx}
                    cy={68 - lift}
                    r={6}
                    fill={idx % 2 === 0 ? THEME.highlight : THEME.teal}
                    opacity={1 - lift / 34}
                  />
                );
              })}
          </svg>
        </div>
      )}
    </AbsoluteFill>
  );
};
