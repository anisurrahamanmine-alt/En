import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import { PersonIcon, DogIcon, CrownIcon, Idle } from "../art/Illustrations";
import { Chip, Stamp, CrossMark } from "../components/EditorialKit";

const START = 1595;

export const Scene05: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const climbP = prog(F, 1620, 32);
  const dogMode = F >= 1890;
  const dogP = sp(F, 1896, "pop");

  return (
    <AbsoluteFill>
      {/* Level Label */}
      <div style={{ position: "absolute", top: 232, left: 72, display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ width: 42, height: 6, borderRadius: 3, backgroundColor: THEME.amber }} />
        <span style={{ fontFamily: FONTS.mono, fontWeight: 700, fontSize: 26, color: THEME.amber }}>
          LEVEL 02 · STATUS NEEDS
        </span>
      </div>

      {/* Phase A (1720–1890): Title, Fame, Power, Respect */}
      {!dogMode && (
        <div
          style={{
            position: "absolute",
            top: 320,
            left: 72,
            right: 72,
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            gap: 18,
          }}
        >
          <Chip label="Big Title" color={THEME.amber} bg={THEME.amberSoft} at={1752} tilt={-2} icon={<CrownIcon size={40} />} />
          <Chip label="Fame" color={THEME.purple} bg={THEME.purpleSoft} at={1788} tilt={1.8} />
          <Chip label="Power" color={THEME.indigo} bg={THEME.indigoSoft} at={1818} tilt={-1.5} />
          <Chip label="Respect" color={THEME.blue} bg={THEME.blueSoft} at={1844} tilt={1.5} />
        </div>
      )}

      {/* Phase B (1890–2185): Dogs Do This Too — Alpha of the Pack */}
      {dogMode && (
        <div style={{ position: "absolute", top: 300, left: 72, right: 72, textAlign: "center" }}>
          <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 54, color: THEME.navy }}>
            BUT DOGS DO THIS TOO!
          </div>
          <div style={{ marginTop: 18, display: "flex", justifyContent: "center", gap: 16, flexWrap: "wrap" }}>
            <Chip label="Mark Territory" color={THEME.amber} bg={THEME.amberSoft} at={1934} />
            <Chip label="Leader of the Pack" color={THEME.coral} bg={THEME.coralSoft} at={1995} />
          </div>
          {F >= 2080 && (
            <div style={{ marginTop: 28 }}>
              <Stamp text="STILL NO DIFFERENCE" at={2080} color={THEME.bad} rot={-3} size={40} />
            </div>
          )}
        </div>
      )}

      {/* 2D Animated Stage */}
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        <line x1={90} y1={1235} x2={990} y2={1235} stroke={THEME.ground} strokeWidth={5} strokeLinecap="round" />

        {/* Level 2 Podium / Platform */}
        <rect
          x={dogMode ? 550 : 280}
          y={1145}
          width={dogMode ? 380 : 520}
          height={90}
          rx={18}
          fill={THEME.amberSoft}
          stroke={THEME.amber}
          strokeWidth={4.5}
        />

        {/* Human climbing to Level 2 */}
        <g
          transform={`translate(${dogMode ? 280 : 540} ${
            dogMode ? 1235 : interpolate(climbP, [0, 1], [1235, 1145])
          })`}
        >
          <Idle amp={3.5} speed={2.2}>
            <PersonIcon pose={dogMode ? "stand" : "celebrate"} cloth={THEME.amber} scale={1.5} dim={dogMode && F >= 2080} />
          </Idle>
        </g>

        {/* Floating Crown above Human (crossed out at f2080) */}
        {!dogMode && F >= 1752 && (
          <g transform="translate(506 740)">
            <Idle amp={5} speed={3}>
              <CrownIcon size={68} />
            </Idle>
          </g>
        )}

        {/* Alpha Dog on Podium + Pack silhouettes */}
        {dogMode && (
          <>
            {/* Expanding scent/territory rings */}
            <circle
              cx={740}
              cy={1060}
              r={40 + ((F * 2.4) % 130)}
              fill="none"
              stroke={THEME.amber}
              strokeWidth={3.5}
              opacity={1 - (((F * 2.4) % 130) / 130)}
            />
            <g transform={`translate(${interpolate(dogP, [0, 1], [1160, 740])} 1145)`} opacity={clamp01(dogP * 1.4)}>
              <Idle amp={3.5} speed={2.5}>
                <DogIcon scale={1.32} collar={THEME.amber} />
              </Idle>
            </g>
            {/* Alpha Crown over Dog */}
            <g transform="translate(715 910)">
              <CrownIcon size={58} />
            </g>
          </>
        )}
      </svg>

      {/* Big Cross over Status Crown at f2080 */}
      {F >= 2080 && (
        <div style={{ position: "absolute", top: 890, left: 685 }}>
          <CrossMark at={2080} size={110} color={THEME.bad} />
        </div>
      )}
    </AbsoluteFill>
  );
};
