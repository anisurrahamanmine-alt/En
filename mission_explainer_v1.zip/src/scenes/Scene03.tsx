import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import { LockIcon } from "../art/Illustrations";

const START = 690;

export const Scene03: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const lockActive = F >= 895;
  const bounceY = lockActive ? Math.sin((F - 895) * 0.35) * 10 : 0;

  const tiers = [
    {
      num: "LEVEL 03",
      title: "Mission",
      sub: "Legacy & Higher Purpose",
      color: THEME.teal,
      bg: THEME.tealSoft,
      at: 822,
      y: 440,
      locked: lockActive,
    },
    {
      num: "LEVEL 02",
      title: "Status Needs",
      sub: "Title, Fame, Power & Respect",
      color: THEME.amber,
      bg: THEME.amberSoft,
      at: 790,
      y: 675,
      locked: lockActive,
    },
    {
      num: "LEVEL 01",
      title: "Physical Needs",
      sub: "Food, Water, Sleep & Survival",
      color: THEME.blue,
      bg: THEME.blueSoft,
      at: 754,
      y: 910,
      locked: false,
    },
  ];

  return (
    <AbsoluteFill>
      {/* Heading */}
      <div style={{ position: "absolute", top: 245, left: 72, right: 72, textAlign: "center" }}>
        <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 58, color: THEME.navy }}>
          3 MAIN LEVELS
        </div>
        <div style={{ fontFamily: FONTS.sans, fontWeight: 600, fontSize: 30, color: THEME.muted, marginTop: 6 }}>
          {lockActive
            ? "Lower needs must be met first"
            : "Maslow’s simplified human ladder"}
        </div>
      </div>

      {/* Stacked Tier Cards */}
      {tiers.map((t, i) => {
        const p = sp(F, t.at, "pop");
        if (F < t.at) return null;
        const dimOpacity = t.locked ? 0.55 : 1;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              top: t.y,
              left: 96,
              right: 96,
              height: 192,
              borderRadius: 28,
              backgroundColor: THEME.card,
              border: `4px solid ${t.color}`,
              boxShadow: THEME.shadow,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "0 36px",
              transform: `translateY(${(1 - p) * 60}px) scale(${0.9 + 0.1 * p})`,
              opacity: clamp01(p * 1.4) * dimOpacity,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 26 }}>
              <div
                style={{
                  width: 92,
                  height: 92,
                  borderRadius: 22,
                  backgroundColor: t.bg,
                  border: `3px solid ${t.color}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontFamily: FONTS.display,
                  fontWeight: 800,
                  fontSize: 44,
                  color: t.color,
                }}
              >
                {3 - i}
              </div>
              <div>
                <div style={{ fontFamily: FONTS.mono, fontWeight: 700, fontSize: 22, color: t.color }}>
                  {t.num}
                </div>
                <div style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 44, color: THEME.navy }}>
                  {t.title}
                </div>
                <div style={{ fontFamily: FONTS.sans, fontWeight: 600, fontSize: 24, color: THEME.muted }}>
                  {t.sub}
                </div>
              </div>
            </div>
            {t.locked && (
              <div style={{ transform: `translateY(${bounceY * 0.4}px)` }}>
                <LockIcon size={58} color={THEME.bad} />
              </div>
            )}
          </div>
        );
      })}

      {/* Upward dashed arrow showing progression rule */}
      {F >= 865 && (
        <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          <path
            d="M 540 905 L 540 875"
            stroke={THEME.blue}
            strokeWidth={6}
            strokeLinecap="round"
            opacity={prog(F, 865, 14)}
          />
          <polygon
            points="540,860 526,882 554,882"
            fill={THEME.blue}
            opacity={prog(F, 865, 14)}
          />
        </svg>
      )}
    </AbsoluteFill>
  );
};
