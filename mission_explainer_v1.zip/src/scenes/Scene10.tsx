import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { THEME } from "../theme";
import { FONTS } from "../fonts";
import { sp, prog, clamp01 } from "../anim";
import { MarkerWord } from "../components/EditorialKit";

const START = 3515;

export const Scene10: React.FC = () => {
  const local = useCurrentFrame();
  const F = local + START;

  const c1 = sp(F, 3580, "pop"); // Know
  const c2 = sp(F, 3608, "pop"); // Good at
  const c3 = sp(F, 3644, "pop"); // Love
  const mergeP = prog(F, 3692, 34); // Bring these three together
  const ripple = ((F - 3710) * 3.2) % 240;

  // Circle centers converge slightly toward (540, 760)
  const spread = interpolate(mergeP, [0, 1], [155, 112]);
  const cx1 = 540;
  const cy1 = 760 - spread;
  const cx2 = 540 - spread * 0.92;
  const cy2 = 760 + spread * 0.65;
  const cx3 = 540 + spread * 0.92;
  const cy3 = 760 + spread * 0.65;

  return (
    <AbsoluteFill>
      {/* Top Headline */}
      <div style={{ position: "absolute", top: 165, left: 72, right: 72, textAlign: "center" }}>
        <div style={{ fontFamily: FONTS.sans, fontWeight: 700, fontSize: 34, color: THEME.muted }}>
          YOUR PERSONAL FORMULA
        </div>
        <MarkerWord text="DEFINE YOUR MISSION" at={3525} bg={THEME.highlight} color={THEME.navy} size={62} />
      </div>

      {/* 3-Circle Venn Diagram SVG */}
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        {/* Positive Change Ripples expanding from core at f3710+ */}
        {F >= 3710 && (
          <>
            <circle
              cx={540}
              cy={770}
              r={120 + ripple}
              fill="none"
              stroke={THEME.teal}
              strokeWidth={4}
              opacity={0.45 * (1 - ripple / 240)}
            />
            <circle
              cx={540}
              cy={770}
              r={120 + ((ripple + 120) % 240)}
              fill="none"
              stroke={THEME.amber}
              strokeWidth={3.5}
              opacity={0.38 * (1 - ((ripple + 120) % 240) / 240)}
            />
          </>
        )}

        {/* Circle 1: WHAT YOU KNOW (Blue) */}
        {F >= 3580 && (
          <g transform={`translate(${cx1} ${cy1}) scale(${c1})`} opacity={clamp01(c1 * 1.3)}>
            <circle r={195} fill="rgba(37, 99, 235, 0.16)" stroke={THEME.blue} strokeWidth={5} />
            <text y={-42} textAnchor="middle" fill={THEME.blue} fontFamily={FONTS.mono} fontWeight={700} fontSize={22}>
              01 · MIND
            </text>
            <text y={-4} textAnchor="middle" fill={THEME.navy} fontFamily={FONTS.display} fontWeight={800} fontSize={34}>
              WHAT YOU
            </text>
            <text y={36} textAnchor="middle" fill={THEME.blue} fontFamily={FONTS.display} fontWeight={800} fontSize={40}>
              KNOW
            </text>
          </g>
        )}

        {/* Circle 2: WHAT YOU ARE GOOD AT (Amber) */}
        {F >= 3608 && (
          <g transform={`translate(${cx2} ${cy2}) scale(${c2})`} opacity={clamp01(c2 * 1.3)}>
            <circle r={195} fill="rgba(217, 119, 6, 0.16)" stroke={THEME.amber} strokeWidth={5} />
            <text y={6} textAnchor="middle" fill={THEME.amber} fontFamily={FONTS.mono} fontWeight={700} fontSize={22}>
              02 · SKILL
            </text>
            <text y={44} textAnchor="middle" fill={THEME.navy} fontFamily={FONTS.display} fontWeight={800} fontSize={32}>
              WHAT YOU’RE
            </text>
            <text y={82} textAnchor="middle" fill={THEME.amber} fontFamily={FONTS.display} fontWeight={800} fontSize={38}>
              GOOD AT
            </text>
          </g>
        )}

        {/* Circle 3: WHAT YOU LOVE (Purple) */}
        {F >= 3644 && (
          <g transform={`translate(${cx3} ${cy3}) scale(${c3})`} opacity={clamp01(c3 * 1.3)}>
            <circle r={195} fill="rgba(124, 58, 237, 0.16)" stroke={THEME.purple} strokeWidth={5} />
            <text y={6} textAnchor="middle" fill={THEME.purple} fontFamily={FONTS.mono} fontWeight={700} fontSize={22}>
              03 · HEART
            </text>
            <text y={44} textAnchor="middle" fill={THEME.navy} fontFamily={FONTS.display} fontWeight={800} fontSize={32}>
              WHAT YOU
            </text>
            <text y={82} textAnchor="middle" fill={THEME.purple} fontFamily={FONTS.display} fontWeight={800} fontSize={38}>
              LOVE
            </text>
          </g>
        )}

        {/* Center Illuminated Core: YOUR MISSION */}
        {F >= 3700 && (
          <g transform={`translate(540 770) scale(${sp(F, 3700, "pop")})`}>
            <circle r={96} fill={THEME.teal} stroke={THEME.white} strokeWidth={7} />
            <text y={-8} textAnchor="middle" fill={THEME.highlight} fontFamily={FONTS.mono} fontWeight={700} fontSize={22}>
              YOUR
            </text>
            <text y={28} textAnchor="middle" fill={THEME.white} fontFamily={FONTS.display} fontWeight={800} fontSize={34}>
              MISSION
            </text>
          </g>
        )}
      </svg>

      {/* Bottom Impact Callout */}
      {F >= 3810 && (
        <div
          style={{
            position: "absolute",
            top: 1140,
            left: 88,
            right: 88,
            backgroundColor: THEME.card,
            border: `3.5px solid ${THEME.teal}`,
            borderRadius: 24,
            padding: "20px 28px",
            boxShadow: THEME.shadowSoft,
            textAlign: "center",
            opacity: prog(F, 3810, 14),
          }}
        >
          <span style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 32, color: THEME.navy }}>
            Call people toward Allah &amp; bring{" "}
          </span>
          <span style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 32, color: THEME.teal }}>
            positive change
          </span>
          <span style={{ fontFamily: FONTS.display, fontWeight: 800, fontSize: 32, color: THEME.navy }}>
            {" "}to the world.
          </span>
        </div>
      )}
    </AbsoluteFill>
  );
};
