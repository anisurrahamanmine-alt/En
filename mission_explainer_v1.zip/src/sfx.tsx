import React from "react";
import { Audio, Sequence, staticFile, interpolate } from "remotion";

export type SfxKey =
  | "whoosh_soft"
  | "whoosh_cinematic"
  | "whoosh_fast"
  | "whoosh_2"
  | "pop"
  | "pop_bubble"
  | "click"
  | "tick"
  | "paper_flip"
  | "paper_slide"
  | "marker"
  | "shutter"
  | "riser"
  | "riser_paper"
  | "boom_soft"
  | "impact_thud"
  | "chime_shine"
  | "chime_sparkle"
  | "ding"
  | "correct"
  | "wrong"
  | "flashback";

export interface SfxCue {
  at: number;       // absolute frame
  key: SfxKey;
  vol?: number;     // 0..1 (calibrated ~15-19 dB below voice)
  len?: number;     // duration in frames
  rate?: number;    // playbackRate
  fadeTo?: number;  // optional secondary fade level
}

// Curated timeline SFX — exclusively from user's Sound Effects SFX.zip
// Zero SFX during Hadith quote recitation words (2860-3000); no background music.
export const SFX_CUES: SfxCue[] = [
  // Scene 01: Hook (stronger opening < f150)
  { at: 2,    key: "whoosh_fast",      vol: 0.30, len: 24 },
  { at: 18,   key: "pop",              vol: 0.24, len: 18 },
  { at: 46,   key: "pop_bubble",       vol: 0.22, len: 18 },
  { at: 74,   key: "click",            vol: 0.22, len: 16 },
  { at: 108,  key: "pop",              vol: 0.22, len: 18 },
  { at: 152,  key: "whoosh_soft",      vol: 0.24, len: 20 },
  { at: 210,  key: "riser_paper",      vol: 0.20, len: 45 },

  // Scene 02: Ladder & Maslow 1943
  { at: 328,  key: "whoosh_cinematic", vol: 0.22, len: 30 },
  { at: 350,  key: "pop",              vol: 0.20, len: 18 },
  { at: 466,  key: "shutter",          vol: 0.24, len: 20 },
  { at: 486,  key: "paper_slide",      vol: 0.20, len: 20 },
  { at: 602,  key: "marker",           vol: 0.20, len: 20 },

  // Scene 03: Three Main Levels
  { at: 692,  key: "paper_flip",       vol: 0.20, len: 20 },
  { at: 760,  key: "pop",              vol: 0.20, len: 18 },
  { at: 794,  key: "pop",              vol: 0.20, len: 18 },
  { at: 826,  key: "ding",             vol: 0.20, len: 26 },
  { at: 912,  key: "impact_thud",      vol: 0.18, len: 22 },

  // Scene 04: Level 1 Physical Needs
  { at: 996,  key: "whoosh_soft",      vol: 0.22, len: 20 },
  { at: 1090, key: "tick",             vol: 0.20, len: 55, rate: 1.8, fadeTo: 0.06 },
  { at: 1165, key: "chime_sparkle",    vol: 0.18, len: 28 },
  { at: 1226, key: "wrong",            vol: 0.22, len: 26 },
  { at: 1265, key: "pop_bubble",       vol: 0.18, len: 16 },
  { at: 1300, key: "pop_bubble",       vol: 0.18, len: 16 },
  { at: 1335, key: "pop_bubble",       vol: 0.18, len: 16 },
  { at: 1425, key: "whoosh_2",         vol: 0.20, len: 20 },
  { at: 1525, key: "impact_thud",      vol: 0.20, len: 22 },

  // Scene 05: Level 2 Status Needs
  { at: 1598, key: "whoosh_cinematic", vol: 0.22, len: 28 },
  { at: 1755, key: "pop",              vol: 0.19, len: 16 },
  { at: 1795, key: "pop",              vol: 0.19, len: 16 },
  { at: 1830, key: "pop",              vol: 0.19, len: 16 },
  { at: 1892, key: "flashback",        vol: 0.20, len: 30 },
  { at: 2085, key: "wrong",            vol: 0.20, len: 26 },

  // Scene 06: Level 3 Mission
  { at: 2186, key: "riser",            vol: 0.20, len: 50 },
  { at: 2268, key: "boom_soft",        vol: 0.24, len: 36 },
  { at: 2274, key: "chime_shine",      vol: 0.20, len: 42 },
  { at: 2285, key: "marker",           vol: 0.19, len: 20 },
  { at: 2386, key: "click",            vol: 0.18, len: 16 },
  { at: 2446, key: "click",            vol: 0.18, len: 16 },
  { at: 2513, key: "chime_sparkle",    vol: 0.18, len: 30 },

  // Scene 07: Mission of a True Muslim (serene, soft)
  { at: 2572, key: "whoosh_soft",      vol: 0.18, len: 24 },
  { at: 2690, key: "chime_shine",      vol: 0.18, len: 42 },

  // Scene 08: Hadith Anchor (Sahih Muslim 1631) — silent during recitation, soft chimes on 3 pillars
  { at: 2770, key: "paper_flip",       vol: 0.18, len: 22 },
  { at: 2985, key: "ding",             vol: 0.16, len: 26 },
  { at: 3020, key: "ding",             vol: 0.16, len: 26 },
  { at: 3055, key: "chime_sparkle",    vol: 0.18, len: 32 },

  // Scene 09: Forms of Mission
  { at: 3098, key: "whoosh_soft",      vol: 0.20, len: 22 },
  { at: 3160, key: "pop",              vol: 0.18, len: 18 },
  { at: 3258, key: "pop",              vol: 0.18, len: 18 },
  { at: 3364, key: "pop",              vol: 0.18, len: 18 },
  { at: 3474, key: "correct",          vol: 0.20, len: 26 },

  // Scene 10: 3-Circle Mission Formula
  { at: 3518, key: "whoosh_2",         vol: 0.20, len: 22 },
  { at: 3583, key: "pop_bubble",       vol: 0.20, len: 18 },
  { at: 3611, key: "pop_bubble",       vol: 0.20, len: 18 },
  { at: 3647, key: "pop_bubble",       vol: 0.20, len: 18 },
  { at: 3705, key: "chime_shine",      vol: 0.22, len: 45 },
  { at: 3825, key: "marker",           vol: 0.18, len: 20 },

  // Scene 11: Full-Circle Callback & Final Resolution
  { at: 3928, key: "whoosh_cinematic", vol: 0.22, len: 28 },
  { at: 4050, key: "impact_thud",      vol: 0.17, len: 22 },
  { at: 4160, key: "boom_soft",        vol: 0.24, len: 42 },
  { at: 4168, key: "chime_shine",      vol: 0.22, len: 55 },
  { at: 4232, key: "marker",           vol: 0.19, len: 22 },
];

export const SfxLayer: React.FC = () => {
  return (
    <>
      {SFX_CUES.map((c, idx) => {
        const len = c.len ?? 30;
        const baseVol = c.vol ?? 0.2;
        return (
          <Sequence key={idx} from={c.at} durationInFrames={len}>
            <Audio
              src={staticFile(`sfx/${c.key}.mp3`)}
              playbackRate={c.rate ?? 1}
              volume={(f) => {
                const endFade = interpolate(f, [Math.max(0, len - 8), len], [1, 0], {
                  extrapolateLeft: "clamp",
                  extrapolateRight: "clamp",
                });
                if (c.fadeTo !== undefined) {
                  const mid = interpolate(f, [0, 12, len], [baseVol, c.fadeTo, 0], {
                    extrapolateLeft: "clamp",
                    extrapolateRight: "clamp",
                  });
                  return mid;
                }
                return baseVol * endFade;
              }}
            />
          </Sequence>
        );
      })}
    </>
  );
};
