import { ASPECT, AspectKey } from "./config";

export const RATIOS = {
  "9:16": {
    w: 1080,
    h: 1920,
    margin: 72,
    tabY: 148,
    tabH: 58,
    labelY: 232,
    stageTop: 260,
    stageBottom: 1350,
    stageCenterY: 790,
    captionY: 1490,
    captionFont: 48,
    captionPillH: 96,
    reserveFrom: 1640,
    rightSafe: 110,
    k: 1,
  },
  "16:9": {
    w: 1920,
    h: 1080,
    margin: 100,
    tabY: 44,
    tabH: 52,
    labelY: 116,
    stageTop: 150,
    stageBottom: 840,
    stageCenterY: 495,
    captionY: 935,
    captionFont: 44,
    captionPillH: 88,
    reserveFrom: 1005,
    rightSafe: 80,
    k: 0.7,
  },
} as const;

export type Layout = (typeof RATIOS)[AspectKey];
export const LAYOUT: Layout = RATIOS[ASPECT];
export const px = (n: number): number => Math.round(n * LAYOUT.k);
