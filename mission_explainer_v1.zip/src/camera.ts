import { interpolate } from "remotion";
import { EASE_IO } from "./anim";

export interface CameraTransform {
  scale: number;
  x: number;
  y: number;
}

/**
 * Continuous editorial camera rig across all 4320 frames.
 * Subtle breathing, punch-in at frame 0, suspense push-ins, gentle settle on Hadith & climax.
 */
export function getCamera(frame: number): CameraTransform {
  // Opening punch-in (f0 -> f18)
  const openScale = interpolate(frame, [0, 18], [1.12, 1.0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: EASE_IO,
  });

  // Gentle push-in on "So where is the real difference?" (f2185 -> f2245)
  const s6Push = interpolate(frame, [2185, 2242, 2260], [0, 0.045, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: EASE_IO,
  });

  // Calm meditative push on Hadith (f2768 -> f3080)
  const hadithPush = interpolate(frame, [2768, 3080, 3100], [0, 0.03, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // Final resolution slow lift (f4140 -> f4320)
  const finalPush = interpolate(frame, [4140, 4320], [0, 0.035], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // Subtle organic breathing
  const breath = Math.sin(frame / 48) * 0.004;

  return {
    scale: openScale + s6Push + hadithPush + finalPush + breath,
    x: Math.sin(frame / 75) * 3,
    y: Math.cos(frame / 90) * 3,
  };
}
