import React from "react";
import { AbsoluteFill } from "remotion";
import "./fonts";
import { THEME } from "./theme";
import { FONTS } from "./fonts";
import { AnimatedBg } from "./components/AnimatedBg";
import { DogIcon, PersonIcon, LadderArt, CompassStarArt } from "./art/Illustrations";

export const Thumbnail: React.FC = () => {
  return (
    <AbsoluteFill>
      <AnimatedBg />
      <div style={{ position: "absolute", top: 200, left: 72, right: 72, textAlign: "center" }}>
        <div
          style={{
            display: "inline-block",
            padding: "10px 26px",
            borderRadius: 999,
            backgroundColor: THEME.navy,
            color: THEME.highlight,
            fontFamily: FONTS.mono,
            fontWeight: 700,
            fontSize: 28,
            marginBottom: 22,
          }}
        >
          HUMAN VS DOG · MASLOW’S LADDER
        </div>
        <div
          style={{
            fontFamily: FONTS.display,
            fontWeight: 800,
            fontSize: 96,
            color: THEME.navy,
            lineHeight: 1.06,
          }}
        >
          THE ONLY REAL{" "}
          <span
            style={{
              backgroundColor: THEME.highlight,
              padding: "4px 20px",
              borderRadius: 16,
              display: "inline-block",
              marginTop: 10,
            }}
          >
            MISSION
          </span>
        </div>
      </div>

      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
        <line x1={90} y1={1460} x2={990} y2={1460} stroke={THEME.ground} strokeWidth={6} strokeLinecap="round" />
        <g transform="translate(540 1460)">
          <LadderArt height={660} width={230} activeLevel={3} />
        </g>
        <g transform="translate(260 1460)">
          <DogIcon scale={1.45} wag={false} />
        </g>
        <g transform="translate(820 1460)">
          <PersonIcon pose="celebrate" cloth={THEME.teal} scale={1.7} />
        </g>
        <g transform="translate(492 670)">
          <CompassStarArt size={96} color={THEME.teal} />
        </g>
      </svg>
    </AbsoluteFill>
  );
};
