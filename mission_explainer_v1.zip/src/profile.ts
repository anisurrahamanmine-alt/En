export const VIDEO_PROFILE = {
  summaryLine:
    "psychology-mission-hybrid | contemporary+1943 | thoughtful-to-inspiring | 3-level-ladder+hadith+formula | en | medium(144s) | adults | 178wpm | real-photo+2d-diagrams+22sfx",
  theme: "Off-White Graph Grid & Multi-Color Editorial-Diagram Hybrid",
  era: "Contemporary (with 1943 archival moment for Abraham Maslow)",
  tone: "Engaging & analytical in Acts 1-2, respectful & serene in Act 3 (Hadith & Mission)",
  structure: "Question Hook -> 3-Level Ladder -> Hadith Anchor -> 3 Mission Archetypes -> 3-Circle Formula -> Full-Circle Callback",
  language: "en",
  aspect: "9:16",
  wpm: 178,
  music: "none" as const,
};
