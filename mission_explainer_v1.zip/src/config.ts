export type AspectKey = "9:16" | "16:9";

export const ASPECT: AspectKey = "9:16";
export const FPS = 30;
export const AUDIO_DURATION_SEC = 142.96;
export const END_HOLD_SEC = 1.04;
export const DURATION_IN_FRAMES = Math.round((AUDIO_DURATION_SEC + END_HOLD_SEC) * FPS); // 4320
export const OVERLAP = 12;

export interface SceneTiming {
  id: string;
  name: string;
  start: number;
  end: number;
  bgMode: "graph" | "dots" | "blueprint" | "arch";
  washPair: [string, string];
  stepTab: 0 | 1 | 2 | 3; // 0 = hidden, 1 = Physical, 2 = Status, 3 = Mission
}

export const SCENES: SceneTiming[] = [
  { id: "Scene01", name: "Hook: Human vs Dog",           start: 0,    end: 325,  bgMode: "graph",     washPair: ["rgba(225,29,72,0.08)",  "rgba(37,99,235,0.08)"],  stepTab: 0 },
  { id: "Scene02", name: "The Ladder & Maslow 1943",     start: 325,  end: 690,  bgMode: "blueprint", washPair: ["rgba(37,99,235,0.09)",  "rgba(217,119,6,0.08)"],  stepTab: 0 },
  { id: "Scene03", name: "Three Main Levels Overview",   start: 690,  end: 995,  bgMode: "graph",     washPair: ["rgba(79,70,229,0.08)",  "rgba(13,148,136,0.08)"], stepTab: 1 },
  { id: "Scene04", name: "Level 1: Physical Needs",      start: 995,  end: 1595, bgMode: "graph",     washPair: ["rgba(37,99,235,0.09)",  "rgba(220,38,38,0.07)"],  stepTab: 1 },
  { id: "Scene05", name: "Level 2: Status Needs",        start: 1595, end: 2185, bgMode: "dots",      washPair: ["rgba(217,119,6,0.10)",  "rgba(124,58,237,0.08)"], stepTab: 2 },
  { id: "Scene06", name: "Level 3: Mission",             start: 2185, end: 2570, bgMode: "graph",     washPair: ["rgba(13,148,136,0.10)", "rgba(252,211,77,0.12)"], stepTab: 3 },
  { id: "Scene07", name: "Mission of a True Muslim",     start: 2570, end: 2768, bgMode: "arch",      washPair: ["rgba(13,148,136,0.10)", "rgba(217,119,6,0.09)"],  stepTab: 0 },
  { id: "Scene08", name: "Hadith: Sahih Muslim 1631",    start: 2768, end: 3095, bgMode: "arch",      washPair: ["rgba(217,119,6,0.10)",  "rgba(13,148,136,0.10)"], stepTab: 0 },
  { id: "Scene09", name: "Forms of Mission in Action",   start: 3095, end: 3515, bgMode: "graph",     washPair: ["rgba(37,99,235,0.08)",  "rgba(13,148,136,0.09)"], stepTab: 0 },
  { id: "Scene10", name: "Define Your Mission (3-Circle)", start: 3515, end: 3925, bgMode: "dots",    washPair: ["rgba(124,58,237,0.09)", "rgba(217,119,6,0.09)"],  stepTab: 0 },
  { id: "Scene11", name: "Callback & Final Resolution",  start: 3925, end: 4320, bgMode: "graph",     washPair: ["rgba(13,148,136,0.11)", "rgba(252,211,77,0.14)"], stepTab: 0 },
];
