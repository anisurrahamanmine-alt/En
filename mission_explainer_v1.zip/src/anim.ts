import { Easing, interpolate, spring } from "remotion";
import { FPS } from "./config";

export const SPRING = {
  pop:  { damping: 11, stiffness: 170, mass: 0.75 },
  snap: { damping: 15, stiffness: 245, mass: 0.6 },
  soft: { damping: 22, stiffness: 115, mass: 0.95 },
  slam: { damping: 9,  stiffness: 260, mass: 0.8 },
} as const;

export const EASE_OUT = Easing.bezier(0.16, 1, 0.3, 1);
export const EASE_IO = Easing.bezier(0.65, 0, 0.35, 1);

export const clamp01 = (v: number): number => Math.min(1, Math.max(0, v));

export const sp = (
  frame: number,
  at: number,
  type: keyof typeof SPRING = "pop"
): number => {
  if (frame < at) return 0;
  return spring({ frame: frame - at, fps: FPS, config: SPRING[type] });
};

export const prog = (frame: number, start: number, dur: number): number =>
  interpolate(frame, [start, start + Math.max(1, dur)], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: EASE_OUT,
  });

export const fadeOut = (frame: number, start: number, dur = 12): number =>
  interpolate(frame, [start, start + dur], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: EASE_OUT,
  });

// Deterministic pseudo-random helper (never use Math.random)
export const rnd = (seed: number): number => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
};
