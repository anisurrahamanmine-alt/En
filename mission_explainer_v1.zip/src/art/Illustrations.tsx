import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { THEME } from "../theme";
import { clamp01, sp } from "../anim";

const easeOutCubic = (x: number) => 1 - Math.pow(1 - clamp01(x), 3);

// ── Whole-object motion wrappers (never limb-rigged) ──
export const Mover: React.FC<{
  from: [number, number];
  to: [number, number];
  start: number;
  dur: number;
  bob?: number;
  tilt?: number;
  children?: React.ReactNode;
}> = ({ from, to, start, dur, bob = 0, tilt = 0, children }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = easeOutCubic((f - start) / Math.max(1, dur));
  const moving = p > 0 && p < 1 ? 1 : 0;
  const t = f / fps;
  const x = from[0] + (to[0] - from[0]) * p;
  const y = from[1] + (to[1] - from[1]) * p + Math.sin(t * 11) * bob * moving;
  return (
    <g transform={`translate(${x} ${y}) rotate(${Math.sin(t * 11) * tilt * moving})`}>
      {children}
    </g>
  );
};

export const PopIn: React.FC<{
  at: number;
  x?: number;
  y?: number;
  children?: React.ReactNode;
}> = ({ at, x = 0, y = 0, children }) => {
  const f = useCurrentFrame();
  const p = sp(f, at, "pop");
  if (f < at) return null;
  return (
    <g
      opacity={clamp01(p * 1.4)}
      transform={`translate(${x} ${y + (1 - p) * 44}) scale(${0.86 + 0.14 * p})`}
    >
      {children}
    </g>
  );
};

export const Idle: React.FC<{
  amp?: number;
  speed?: number;
  phase?: number;
  children?: React.ReactNode;
}> = ({ amp = 3.5, speed = 2.2, phase = 0, children }) => {
  const t = useCurrentFrame() / useVideoConfig().fps;
  return <g transform={`translate(0 ${Math.sin(t * speed + phase) * amp})`}>{children}</g>;
};

// ── Flat 2D Person Icon: origin (0,0) = bottom-center of feet, height ~210 * scale ──
export type PersonPose = "stand" | "point" | "think" | "hold" | "celebrate";

export const PersonIcon: React.FC<{
  pose?: PersonPose;
  cloth?: string;
  skin?: string;
  hair?: string;
  scale?: number;
  flip?: boolean;
  dim?: boolean;
}> = ({
  pose = "stand",
  cloth = THEME.blue,
  skin = THEME.skinA,
  hair = THEME.hairDark,
  scale = 1,
  flip = false,
  dim = false,
}) => {
  const line = THEME.navy;
  const S = {
    stroke: line,
    strokeWidth: 4.5,
    strokeLinejoin: "round" as const,
    strokeLinecap: "round" as const,
  };
  return (
    <g transform={`scale(${flip ? -scale : scale}, ${scale})`} opacity={dim ? 0.38 : 1}>
      {/* Ground shadow */}
      <ellipse cx={0} cy={2} rx={38} ry={8} fill="rgba(20,33,61,0.13)" />
      {/* Legs */}
      <rect x={-24} y={-74} width={20} height={74} rx={10} fill={THEME.navy} {...S} />
      <rect x={4} y={-74} width={20} height={74} rx={10} fill={THEME.navy} {...S} />
      {/* Arms by static pose */}
      {pose === "stand" && (
        <>
          <rect x={-52} y={-136} width={17} height={68} rx={8.5} fill={skin} {...S} />
          <rect x={35} y={-136} width={17} height={68} rx={8.5} fill={skin} {...S} />
        </>
      )}
      {pose === "point" && (
        <>
          <rect x={-52} y={-136} width={17} height={68} rx={8.5} fill={skin} {...S} />
          <path d="M 32 -122 L 96 -144" stroke={line} strokeWidth={24} strokeLinecap="round" fill="none" />
          <path d="M 32 -122 L 96 -144" stroke={skin} strokeWidth={15} strokeLinecap="round" fill="none" />
        </>
      )}
      {pose === "think" && (
        <>
          <rect x={-52} y={-136} width={17} height={68} rx={8.5} fill={skin} {...S} />
          <path d="M 32 -122 Q 44 -146 14 -148" stroke={line} strokeWidth={22} strokeLinecap="round" fill="none" />
          <path d="M 32 -122 Q 44 -146 14 -148" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
        </>
      )}
      {pose === "hold" && (
        <>
          <path d="M -32 -120 L 4 -98 M 32 -120 L 4 -98" stroke={line} strokeWidth={22} strokeLinecap="round" fill="none" />
          <path d="M -32 -120 L 4 -98 M 32 -120 L 4 -98" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
          <rect x={-14} y={-118} width={36} height={26} rx={5} fill={THEME.highlight} {...S} strokeWidth={3.5} />
        </>
      )}
      {pose === "celebrate" && (
        <>
          <path d="M -32 -124 L -72 -176" stroke={line} strokeWidth={22} strokeLinecap="round" fill="none" />
          <path d="M -32 -124 L -72 -176" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
          <path d="M 32 -124 L 72 -176" stroke={line} strokeWidth={22} strokeLinecap="round" fill="none" />
          <path d="M 32 -124 L 72 -176" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
        </>
      )}
      {/* Torso */}
      <rect x={-35} y={-144} width={70} height={80} rx={26} fill={cloth} {...S} />
      {/* Collar detail */}
      <path d="M -14 -144 L 0 -128 L 14 -144" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth={4} strokeLinecap="round" />
      {/* Head */}
      <circle cx={0} cy={-174} r={31} fill={skin} {...S} />
      {/* Hair */}
      <path d="M -31 -178 Q -28 -212 2 -210 Q 30 -208 31 -178 Q 10 -192 -31 -178 Z" fill={hair} />
      {/* Eyes & Smile */}
      <circle cx={-10} cy={-172} r={3.5} fill={line} />
      <circle cx={10} cy={-172} r={3.5} fill={line} />
      <path d="M -9 -159 Q 0 -152 9 -159" stroke={line} strokeWidth={3.5} fill="none" strokeLinecap="round" />
    </g>
  );
};

// ── Flat 2D Dog Icon: origin (0,0) = bottom-center of paws, width ~190 * scale ──
export const DogIcon: React.FC<{
  fur?: string;
  ear?: string;
  collar?: string;
  scale?: number;
  flip?: boolean;
  dim?: boolean;
  wag?: boolean;
}> = ({
  fur = THEME.dogFur,
  ear = THEME.dogEar,
  collar = THEME.coral,
  scale = 1,
  flip = false,
  dim = false,
  wag = true,
}) => {
  const f = useCurrentFrame();
  const tailAngle = wag ? Math.sin(f * 0.35) * 14 : 0;
  const line = THEME.navy;
  const S = {
    stroke: line,
    strokeWidth: 4.5,
    strokeLinejoin: "round" as const,
    strokeLinecap: "round" as const,
  };
  return (
    <g transform={`scale(${flip ? -scale : scale}, ${scale})`} opacity={dim ? 0.38 : 1}>
      <ellipse cx={0} cy={2} rx={68} ry={9} fill="rgba(20,33,61,0.13)" />
      {/* Tail */}
      <g transform={`translate(-66 -74) rotate(${tailAngle})`}>
        <path d="M 0 0 Q -28 -26 -16 -46" fill="none" stroke={line} strokeWidth={18} strokeLinecap="round" />
        <path d="M 0 0 Q -28 -26 -16 -46" fill="none" stroke={fur} strokeWidth={10} strokeLinecap="round" />
      </g>
      {/* Back legs */}
      <rect x={-56} y={-50} width={18} height={50} rx={9} fill={ear} {...S} />
      <rect x={28} y={-50} width={18} height={50} rx={9} fill={ear} {...S} />
      {/* Body */}
      <rect x={-70} y={-92} width={128} height={56} rx={26} fill={fur} {...S} />
      {/* Front legs */}
      <rect x={-38} y={-48} width={18} height={48} rx={9} fill={fur} {...S} />
      <rect x={40} y={-48} width={18} height={48} rx={9} fill={fur} {...S} />
      {/* Collar */}
      <rect x={34} y={-96} width={28} height={14} rx={6} fill={collar} {...S} strokeWidth={3.5} />
      {/* Head */}
      <rect x={32} y={-144} width={66} height={54} rx={22} fill={fur} {...S} />
      {/* Snout */}
      <rect x={76} y={-124} width={30} height={26} rx={12} fill="#F3D5B5" {...S} strokeWidth={3.5} />
      {/* Nose */}
      <ellipse cx={102} cy={-118} rx={7} ry={5} fill={line} />
      {/* Floppy Ear */}
      <path d="M 40 -138 Q 20 -134 24 -100 Q 38 -94 48 -108 Z" fill={ear} {...S} />
      {/* Eye */}
      <circle cx={72} cy={-126} r={4.5} fill={line} />
      <circle cx={73.5} cy={-127.5} r={1.5} fill="#FFFFFF" />
    </g>
  );
};

// ── 3-Rung Editorial Ladder: origin (0,0) = bottom-center ──
export const LadderArt: React.FC<{
  height?: number;
  width?: number;
  activeLevel?: 0 | 1 | 2 | 3;
}> = ({ height = 640, width = 220, activeLevel = 0 }) => {
  const half = width / 2;
  const rungYs = [-height * 0.22, -height * 0.52, -height * 0.82];
  const rungColors = [THEME.blue, THEME.amber, THEME.teal];
  return (
    <g>
      {/* Left & Right Rails */}
      <rect x={-half} y={-height} width={20} height={height} rx={10} fill={THEME.navy} />
      <rect x={half - 20} y={-height} width={20} height={height} rx={10} fill={THEME.navy} />
      {/* Subtle rail highlights */}
      <rect x={-half + 4} y={-height + 12} width={5} height={height - 24} rx={2.5} fill="rgba(255,255,255,0.22)" />
      <rect x={half - 16} y={-height + 12} width={5} height={height - 24} rx={2.5} fill="rgba(255,255,255,0.22)" />
      {/* 3 Major Rungs */}
      {rungYs.map((ry, i) => {
        const levelNum = (i + 1) as 1 | 2 | 3;
        const isActive = activeLevel === levelNum || activeLevel === 0;
        const fill = isActive ? rungColors[i] : "#CBD5E1";
        return (
          <g key={i}>
            <rect
              x={-half + 14}
              y={ry - 11}
              width={width - 28}
              height={22}
              rx={8}
              fill={fill}
              stroke={THEME.navy}
              strokeWidth={4}
            />
            {activeLevel === levelNum && (
              <rect
                x={-half + 8}
                y={ry - 17}
                width={width - 16}
                height={34}
                rx={12}
                fill="none"
                stroke={rungColors[i]}
                strokeWidth={3}
                opacity={0.45}
              />
            )}
          </g>
        );
      })}
    </g>
  );
};

// ── Inline Flat Icons (Zero Emoji / Zero Dingbats) ──
export const FoodBowlIcon: React.FC<{ size?: number }> = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64">
    <path d="M 10 34 L 54 34 L 48 52 L 16 52 Z" fill={THEME.coral} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
    <ellipse cx={32} cy={34} rx={22} ry={7} fill={THEME.highlight} stroke={THEME.navy} strokeWidth={3.5} />
    <path d="M 22 22 Q 25 14 22 8 M 32 20 Q 35 12 32 6 M 42 22 Q 45 14 42 8" stroke={THEME.amber} strokeWidth={3} strokeLinecap="round" fill="none" />
  </svg>
);

export const SleepMoonIcon: React.FC<{ size?: number }> = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64">
    <path d="M 38 12 A 20 20 0 1 0 52 42 A 15 15 0 1 1 38 12 Z" fill={THEME.indigo} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
    <circle cx={46} cy={18} r={3.5} fill={THEME.highlight} />
    <circle cx={54} cy={28} r={2.5} fill={THEME.highlight} />
  </svg>
);

export const ShieldGuardIcon: React.FC<{ size?: number }> = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64">
    <path d="M 32 8 L 52 16 V 32 C 52 45 43 53 32 57 C 21 53 12 45 12 32 V 16 Z" fill={THEME.amber} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
    <path d="M 32 16 V 49" stroke="rgba(255,255,255,0.45)" strokeWidth={3} strokeLinecap="round" />
  </svg>
);

export const HeartMateIcon: React.FC<{ size?: number }> = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64">
    <path d="M 32 52 C 14 40 10 28 10 21 A 12 12 0 0 1 32 16 A 12 12 0 0 1 54 21 C 54 28 50 40 32 52 Z" fill={THEME.purple} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
  </svg>
);

export const CrownIcon: React.FC<{ size?: number; color?: string }> = ({ size = 68, color = THEME.highlight }) => (
  <svg width={size} height={size} viewBox="0 0 68 68">
    <path d="M 10 48 L 14 20 L 26 32 L 34 14 L 42 32 L 54 20 L 58 48 Z" fill={color} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
    <rect x={10} y={48} width={48} height={9} rx={4} fill={THEME.amber} stroke={THEME.navy} strokeWidth={3.5} />
    <circle cx={34} cy={12} r={4} fill={THEME.coral} stroke={THEME.navy} strokeWidth={2.5} />
  </svg>
);

export const NobelMedalArt: React.FC<{ size?: number }> = ({ size = 136 }) => (
  <svg width={size} height={size} viewBox="0 0 136 136">
    <path d="M 46 8 L 62 56 L 44 56 L 28 8 Z" fill={THEME.blue} stroke={THEME.navy} strokeWidth={3.5} />
    <path d="M 90 8 L 74 56 L 92 56 L 108 8 Z" fill={THEME.indigo} stroke={THEME.navy} strokeWidth={3.5} />
    <circle cx={68} cy={82} r={42} fill={THEME.highlight} stroke={THEME.navy} strokeWidth={4.5} />
    <circle cx={68} cy={82} r={31} fill="none" stroke={THEME.amber} strokeWidth={3} strokeDasharray="6 4" />
    <path d="M 68 60 L 74 74 L 89 75 L 78 85 L 81 100 L 68 92 L 55 100 L 58 85 L 47 75 L 62 74 Z" fill={THEME.amber} stroke={THEME.navy} strokeWidth={2.5} strokeLinejoin="round" />
  </svg>
);

export const LockIcon: React.FC<{ size?: number; color?: string }> = ({ size = 56, color = THEME.bad }) => (
  <svg width={size} height={size} viewBox="0 0 56 56">
    <path d="M 18 25 V 18 A 10 10 0 0 1 38 18 V 25" fill="none" stroke={THEME.navy} strokeWidth={5} strokeLinecap="round" />
    <rect x={12} y={24} width={32} height={24} rx={7} fill={color} stroke={THEME.navy} strokeWidth={3.5} />
    <circle cx={28} cy={35} r={3.5} fill="#FFFFFF" />
    <rect x={26.5} y={36} width={3} height={6} rx={1.5} fill="#FFFFFF" />
  </svg>
);

export const MosqueArt: React.FC<{ size?: number }> = ({ size = 120 }) => (
  <svg width={size} height={size} viewBox="0 0 120 120">
    {/* Minarets */}
    <rect x={14} y={36} width={14} height={68} rx={3} fill={THEME.tealSoft} stroke={THEME.navy} strokeWidth={3.5} />
    <path d="M 14 36 L 21 20 L 28 36 Z" fill={THEME.teal} stroke={THEME.navy} strokeWidth={3} />
    <rect x={92} y={36} width={14} height={68} rx={3} fill={THEME.tealSoft} stroke={THEME.navy} strokeWidth={3.5} />
    <path d="M 92 36 L 99 20 L 106 36 Z" fill={THEME.teal} stroke={THEME.navy} strokeWidth={3} />
    {/* Main Dome */}
    <path d="M 32 62 C 32 30 60 22 60 16 C 60 22 88 30 88 62 Z" fill={THEME.teal} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
    {/* Base */}
    <rect x={26} y={62} width={68} height={42} rx={5} fill={THEME.card} stroke={THEME.navy} strokeWidth={3.5} />
    {/* Arch Door */}
    <path d="M 48 104 V 82 A 12 12 0 0 1 72 82 V 104 Z" fill={THEME.highlight} stroke={THEME.navy} strokeWidth={3.5} />
    <line x1={8} y1={104} x2={112} y2={104} stroke={THEME.navy} strokeWidth={4} strokeLinecap="round" />
  </svg>
);

export const OpenBookArt: React.FC<{ size?: number; color?: string }> = ({ size = 110, color = THEME.blue }) => (
  <svg width={size} height={size} viewBox="0 0 110 110">
    <path d="M 12 30 Q 34 22 55 34 Q 76 22 98 30 V 84 Q 76 76 55 88 Q 34 76 12 84 Z" fill={THEME.card} stroke={THEME.navy} strokeWidth={4} strokeLinejoin="round" />
    <line x1={55} y1={34} x2={55} y2={88} stroke={THEME.navy} strokeWidth={3.5} />
    <line x1={22} y1={46} x2={44} y2={48} stroke={color} strokeWidth={4} strokeLinecap="round" />
    <line x1={22} y1={58} x2={44} y2={60} stroke={color} strokeWidth={4} strokeLinecap="round" />
    <line x1={22} y1={70} x2={38} y2={71} stroke={THEME.muted} strokeWidth={3.5} strokeLinecap="round" />
    <line x1={66} y1={48} x2={88} y2={46} stroke={color} strokeWidth={4} strokeLinecap="round" />
    <line x1={66} y1={60} x2={88} y2={58} stroke={color} strokeWidth={4} strokeLinecap="round" />
    <line x1={66} y1={71} x2={82} y2={70} stroke={THEME.muted} strokeWidth={3.5} strokeLinecap="round" />
  </svg>
);

export const TreeCharityArt: React.FC<{ size?: number }> = ({ size = 110 }) => (
  <svg width={size} height={size} viewBox="0 0 110 110">
    <rect x={48} y={62} width={14} height={34} rx={5} fill="#92400E" stroke={THEME.navy} strokeWidth={3.5} />
    <circle cx={55} cy={42} r={26} fill={THEME.teal} stroke={THEME.navy} strokeWidth={3.5} />
    <circle cx={34} cy={54} r={18} fill={THEME.good} stroke={THEME.navy} strokeWidth={3.5} />
    <circle cx={76} cy={54} r={18} fill={THEME.good} stroke={THEME.navy} strokeWidth={3.5} />
    <circle cx={48} cy={38} r={4} fill={THEME.highlight} />
    <circle cx={65} cy={46} r={4} fill={THEME.highlight} />
    <circle cx={36} cy={52} r={3.5} fill={THEME.highlight} />
    <line x1={22} y1={96} x2={88} y2={96} stroke={THEME.navy} strokeWidth={4} strokeLinecap="round" />
  </svg>
);

export const RighteousChildArt: React.FC<{ size?: number }> = ({ size = 110 }) => (
  <svg width={size} height={size} viewBox="0 0 110 110">
    <circle cx={55} cy={36} r={16} fill={THEME.skinA} stroke={THEME.navy} strokeWidth={3.5} />
    <path d="M 39 34 Q 41 18 55 18 Q 69 18 71 34 Q 55 26 39 34 Z" fill={THEME.hairDark} />
    <path d="M 32 92 C 32 66 78 66 78 92 Z" fill={THEME.purple} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
    {/* Rising prayer light */}
    <path d="M 55 14 L 55 5 M 38 18 L 32 11 M 72 18 L 78 11" stroke={THEME.amber} strokeWidth={3.5} strokeLinecap="round" />
    <path d="M 48 64 L 55 56 L 62 64" fill="none" stroke={THEME.highlight} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const CreatorFrameArt: React.FC<{ size?: number }> = ({ size = 110 }) => (
  <svg width={size} height={size} viewBox="0 0 110 110">
    <rect x={14} y={24} width={82} height={58} rx={12} fill={THEME.indigoSoft} stroke={THEME.navy} strokeWidth={4} />
    <polygon points="46,40 46,66 70,53" fill={THEME.indigo} stroke={THEME.navy} strokeWidth={3.5} strokeLinejoin="round" />
    {/* Broadcast signal arcs */}
    <path d="M 86 14 Q 98 20 100 32" fill="none" stroke={THEME.coral} strokeWidth={3.5} strokeLinecap="round" />
    <path d="M 78 10 Q 98 16 104 38" fill="none" stroke={THEME.amber} strokeWidth={3} strokeLinecap="round" opacity={0.7} />
    <line x1={30} y1={92} x2={80} y2={92} stroke={THEME.navy} strokeWidth={4} strokeLinecap="round" />
  </svg>
);

export const GlobeArt: React.FC<{ size?: number }> = ({ size = 140 }) => (
  <svg width={size} height={size} viewBox="0 0 140 140">
    <circle cx={70} cy={70} r={54} fill={THEME.blueSoft} stroke={THEME.navy} strokeWidth={4.5} />
    <ellipse cx={70} cy={70} rx={26} ry={54} fill="none" stroke={THEME.blue} strokeWidth={3} />
    <line x1={16} y1={70} x2={124} y2={70} stroke={THEME.blue} strokeWidth={3} />
    <path d="M 24 44 Q 70 54 116 44 M 24 96 Q 70 86 116 96" fill="none" stroke={THEME.blue} strokeWidth={2.5} />
    {/* Stylized land masses */}
    <path d="M 46 36 Q 64 30 74 44 Q 68 58 50 54 Z" fill={THEME.teal} opacity={0.78} />
    <path d="M 78 64 Q 98 60 104 78 Q 90 92 76 82 Z" fill={THEME.good} opacity={0.78} />
    <path d="M 32 72 Q 46 70 50 86 Q 38 96 28 84 Z" fill={THEME.teal} opacity={0.72} />
  </svg>
);

export const CompassStarArt: React.FC<{ size?: number; color?: string }> = ({ size = 96, color = THEME.teal }) => (
  <svg width={size} height={size} viewBox="0 0 96 96">
    <circle cx={48} cy={48} r={40} fill={THEME.card} stroke={THEME.navy} strokeWidth={4} />
    <circle cx={48} cy={48} r={31} fill="none" stroke={THEME.amber} strokeWidth={2.5} strokeDasharray="5 5" />
    <polygon points="48,14 57,48 48,82 39,48" fill={color} stroke={THEME.navy} strokeWidth={3} strokeLinejoin="round" />
    <polygon points="14,48 48,39 82,48 48,57" fill={THEME.highlight} stroke={THEME.navy} strokeWidth={3} strokeLinejoin="round" />
    <circle cx={48} cy={48} r={6} fill={THEME.navy} />
  </svg>
);
