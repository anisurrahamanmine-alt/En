import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import "./fonts";
import { SCENES, OVERLAP } from "./config";
import { getCamera } from "./camera";
import { AnimatedBg } from "./components/AnimatedBg";
import { StepTabBar } from "./components/EditorialKit";
import { KineticCaptionBar } from "./components/KineticCaptionBar";
import { SceneShell, TransitionType } from "./components/SceneShell";
import { SfxLayer } from "./sfx";

import { Scene01 } from "./scenes/Scene01";
import { Scene02 } from "./scenes/Scene02";
import { Scene03 } from "./scenes/Scene03";
import { Scene04 } from "./scenes/Scene04";
import { Scene05 } from "./scenes/Scene05";
import { Scene06 } from "./scenes/Scene06";
import { Scene07 } from "./scenes/Scene07";
import { Scene08 } from "./scenes/Scene08";
import { Scene09 } from "./scenes/Scene09";
import { Scene10 } from "./scenes/Scene10";
import { Scene11 } from "./scenes/Scene11";

const SCENE_LIST: {
  Comp: React.FC;
  enter: TransitionType;
  exit: TransitionType;
}[] = [
  { Comp: Scene01, enter: "zoomIn",    exit: "pushUp" },
  { Comp: Scene02, enter: "pushUp",    exit: "fromLeft" },
  { Comp: Scene03, enter: "fromRight", exit: "fade" },
  { Comp: Scene04, enter: "pushUp",    exit: "fromLeft" },
  { Comp: Scene05, enter: "fromRight", exit: "fade" },
  { Comp: Scene06, enter: "zoomIn",    exit: "fade" },
  { Comp: Scene07, enter: "fade",      exit: "fade" },
  { Comp: Scene08, enter: "pushUp",    exit: "fade" },
  { Comp: Scene09, enter: "fromRight", exit: "fromLeft" },
  { Comp: Scene10, enter: "zoomIn",    exit: "fade" },
  { Comp: Scene11, enter: "pushUp",    exit: "fade" },
];

export const MainVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const cam = getCamera(frame);

  const activeScene =
    SCENES.find((s) => frame >= s.start && frame < s.end) ?? SCENES[SCENES.length - 1];

  return (
    <AbsoluteFill>
      {/* Continuous Off-White Graph Grid + Multi-Color Washes Background */}
      <AnimatedBg />

      {/* Camera-driven Stage Container */}
      <AbsoluteFill
        style={{
          transform: `translate3d(${cam.x}px, ${cam.y}px, 0) scale(${cam.scale})`,
          transformOrigin: "50% 44%",
        }}
      >
        {SCENES.map((sc, idx) => {
          const item = SCENE_LIST[idx];
          const isLast = idx === SCENES.length - 1;
          const dur = sc.end - sc.start + (isLast ? 0 : OVERLAP);
          return (
            <Sequence key={sc.id} from={sc.start} durationInFrames={dur}>
              <SceneShell durationInFrames={dur} enter={item.enter} exit={isLast ? "fade" : item.exit}>
                <item.Comp />
              </SceneShell>
            </Sequence>
          );
        })}
      </AbsoluteFill>

      {/* Persistent Step Tab Bar (only active during Maslow's 3-level walk-through) */}
      <StepTabBar activeStep={activeScene.stepTab} />

      {/* Word-Synced Editorial Caption Pill */}
      <KineticCaptionBar />

      {/* Curated SFX Layer (from user's SFX ZIP only) */}
      <SfxLayer />

      {/* Untouched Original Voiceover Audio */}
      <Audio src={staticFile("audio/voiceover.wav")} volume={1} />
    </AbsoluteFill>
  );
};
